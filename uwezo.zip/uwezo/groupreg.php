<?php
session_start();
include("head.php");
if(isset($_SESSION["userid"]))
{
		if($_SESSION["type"]=="admin")
	{
?>
								    <div align="center" id="menu"class="header" ><span class="style13"><a href="grouploc.php" ><h3>Next(2/3):Group and Business Location</h3></a><a href="#"><h3>~~~~~~~~</h3>
								    </a></span>
								      <p class="style13"><a href="groupmembloan.php"><h3> Last(3/3):Group Membership and Loan Information</h3></a><a href="#"><h3>~~~~~~~~</h3></a></p>
                                      
      <p class="style13"><a href="http://localhost/uwezo/ex_mysql2/app1genpdf.php"><h3> Generate Group Information Report </h3><h3>~~~~~~~~</h3></a></p>
      
            <p class="style13"><a href="http://localhost/uwezo/ex_mysql2/app2genpdf.php"><h3> Generate Group Location Report</h3><h3>~~~~~~~~</h3></a></p>                                   								
            <p class="style13"><a href="http://localhost/uwezo/ex_mysql2/app3genpdf.php"><h3> Generate Group Location Report</h3><h3>~~~~~~~~</h3></a></p>                                                                       
                                                                    <p class="style13"><a href="logout.php"><h3> Admin Logout</h3><h3>~~~~~~~~</h3></a></p>
                                      								 
                                     								      </a>
                <p class="style13"><h3> Click Below to Close applications</h3>                            								      </p>
                                                                          
                                      <p class="style13"><a href="closurenotice.php?view=err"><img src='../images/icon.png' width='32' height='32'  onclick="return confirm('Are you sure you want to close the Loan Application Process?')"/></a></p>
                                      <p class="style13"><h3> Click Below to Open applications</h3>                            								      </p>
                                                                            <p class="style13"><a href="opennotice.php?view=opp"><img src='../images/icon.png' width='32' height='32'  onclick="return confirm('Are you sure you want to open the Loan Application Process?')"/></a></p>
                                      
</div>

<?php
//attempt connection to MySQL Database
$mysqli = new mysqli("localhost","root","","uwezo");
if ($mysqli === false) {
die("ERROR: Could not connect to database. " . mysqli_connect_error());
}
$submitted = false;
//if form submitted
//process form input
if(isset($_POST['submit'])) {
//open message block
$submitted = true;
echo '<div id="message">';

//retrieve and check input values
$inputError = false;
if (empty($_POST['grp_name'])) {
echo 'ERROR: Please Enter a Valid Group Name';
$inputError = true;

} else {
$name = $mysqli->escape_string($_POST['grp_name']);
}

if ($inputError != true && empty($_POST['grp_reg'])) {
echo 'ERROR: Please Enter a valid Group Registration Number';
$inputError = true;
} else {
$reg = $mysqli->escape_string($_POST['grp_reg']);
}

if ($inputError != true && empty($_POST['grp_date'])) {
echo 'ERROR: Please Enter a valid date of Registration of the Group';
$inputError = true;
} else {
$date = $mysqli->escape_string($_POST['grp_date']);
}

if ($inputError != true && empty($_POST['grp_town'])) {
echo 'ERROR: Please Enter a valid town name';
$inputError = true;
} else {
$twn = $mysqli->escape_string($_POST['grp_town']);
}

if ($inputError != true && empty($_POST['grp_bankac'])) {
echo 'ERROR: Please Enter a valid Bank Account Number for the group';
$inputError = true;
} else {
$bankacc = $mysqli->escape_string($_POST['grp_bankac']);
}
if ($inputError != true && empty($_POST['grp_bank'])) {
echo 'ERROR: Please Enter a valid Bank Name of the Group ';
$inputError = true;
} else {
$bank = $mysqli->escape_string($_POST['grp_bank']);
}
if ($inputError != true && empty($_POST['grp_bankbra'])) {
echo 'ERROR: Please Enter a valid Bank Branch of the Group ';
$inputError = true;
} else {
$bankbranch = $mysqli->escape_string($_POST['grp_bankbra']);
}

if ($inputError != true && empty($_POST['grp_postcode'])) {
echo 'ERROR: Please Enter a valid Postal Code of the Post Office for the Group';
$inputError = true;
} else {
$postcode = $mysqli->escape_string($_POST['grp_postcode']);
}

if ($inputError != true && empty($_POST['grp_address'])) {
echo 'ERROR: Please Enter a valid Group Postal Address';
$inputError = true;
} else {
$address = $mysqli->escape_string($_POST['grp_address']);
}
//add values to database using INSERT query
if ($inputError != true) {
$sql = "INSERT INTO tblgroupinfo(GroupName, GroupReg, GroupDateOfReg, GroupTown, GroupBankAcc, GroupBank, GroupBankBra,GroupPostCode,GroupAddress) VALUES ('$name','$reg','$date','$twn', '$bankacc', '$bank','$bankbranch','$postcode','$address')";
		if ($mysqli->query($sql) === true) {
		echo 'New record Added with ID: ' .$reg;
		} else {
		echo "ERROR: Could not execute query: $sql. " . $mysqli->error;
		}
	}
	//close message block
	echo '</div>';
	}
	if (($submitted == true && $inputError == false) || $submitted == false) {
	?>
	</div>
		
	<h3> Group Details - Submissions</h3>
        <h5>&nbsp;</h5>
	<?php
	}
	//get records
	//format as HTML table
	$sql = "SELECT GroupName, GroupReg, GroupDateOfReg, GroupTown, GroupBankAcc, GroupBank, GroupBankBra,GroupPostCode,GroupAddress FROM tblgroupinfo";
	if ($result = $mysqli->query($sql)) {
	if ($result->num_rows > 0) {
		echo "<table border='1'>\n";
	echo "<tr class=\"heading\">\n";
	echo "<td>Name</td>\n";
	echo "<td>Reg</td>\n";
	echo "<td>DateOfreg</td>\n";
	echo "<td>Town</td>\n";
	echo "<td>Account No.</td>\n";
	echo "<td>Bank</td>\n";
	echo "<td>Bank Branch</td>\n";
	echo "<td>PostCode</td>\n";
	echo "<td>Address</td>\n";
	echo "</tr>\n";
	while ($row=$result->fetch_object()) {
	
	echo "<tr>\n";
	echo "<td>" .  $row->GroupName . "</td>\n";
	echo "<td>" .  $row->GroupReg . "</td>\n";
	echo "<td>" .  $row->GroupDateOfReg . "</td>\n";
	echo "<td>" .  $row->GroupTown . "</td>\n";
	echo "<td>" .  $row->GroupBankAcc . "</td>\n";
	echo "<td>" .  $row->GroupBank . "</td>\n";
	echo "<td>" .  $row->GroupBankBra. "</td>\n";
	echo "<td>" .  $row->GroupPostCode . "</td>\n";
	echo "<td>" .  $row->GroupAddress . "</td>\n";
	echo "</tr>\n";
	}
	echo "</table>";
	$result->close();
	} else {
	echo "No groups in database.";
	}
	}else {
	echo "ERROR: Could not execute query: $sql. " . $mysqli->error;
	}
	//close connection
	$mysqli->close();
	?>
</body>
</html>
<?php 
}
}
else
{
		header("Location: index.php");
}


?>