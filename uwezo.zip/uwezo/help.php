<?php
include("head.php");
include("conection.php");

if(isset($_POST["button"]))
{
header ("location: index.html");
}





?>
<section id="page">
<header id="pageheader" class="normalheader">
<h2 class="sitedescription">
 </h2>
</header>

<section id="contents">

<article class="post">
  <header class="postheader"><img src='images/logo.png' width="224" height="159"   />
  <h2> How to Use the Loan Application Portal</h2>

  </header>
  <section class="entry">


<h4>Step 1: Register the Group as a Leader</h4>
                            As a new user make sure you  FIRST <a href="register.php">Register Your Group </a> 
 <h4>Step 2: Log in to the Portal with Group Registration Number </h4>                                                       After entering all the details log in with the group registration number or you already have an account <a href="index.php">Log in To the Portal </a>
 
  <h4>Step 3: Fill in the Loan Application Form</h4>                                                      The Loan Application Form is divided into three parts: <br>
  <ul><li>Group Details: Where you enter the basic information about the group</li>
  <li>Group and Business Location: Where you enter the information about the location of the group and the business run by the business</li>
   <li>Group Membership and Loan: Where you enter the information about the members of the group and the loan being applied for by each member</li>
  </ul>
   <h4>Step 4: Await a notification </h4>                                                       A notification on loan approvals is given in the loan approval tab when you log in as a group once the loan of individual members of the group are approved.
      <h4>Step 5: Check - in Approvals </h4>As the leader of the group notify the Uwezo Team that you approve of the Loan Application approvals by checking in a loan approval.
      You check in the approval by clicking the <img src='../images/icon.png' width='32' height='32'> logo on the left most column of the table.

               
  </section>
</article>


</section>

<p>&nbsp;</p>
<form name="form1" method="post" action="">
  <input type="submit" name="button" id="button" value="Back to Site">
</form>
