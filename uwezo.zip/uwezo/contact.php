		<script type="text/javascript" src="lib/jquery-1.3.2.min.js"></script>
		<script type="text/javascript" src="lib/jquery.tools.js"></script>
    	<script type="text/javascript" src="lib/jquery.custom.js"></script>

        <link href="styles.css" rel="stylesheet" type="text/css" media="screen" />
        <style type="text/css">
<!--
.style1 {color: #000000}
-->
        </style>
<?php
include("head.php");
include("validation.php");
?>
<section id="page">
<header id="pageheader" class="normalheader">
<h2 class="sitedescription">
  </h2>
</header>
<img src='images/logo.png' width="224" height="159"   />
<section id="contents">

<article class="post">
  <header class="postheader">
  <h4>Contact us: Please enter Name, Email, Mobile Number, Subject, Message</h4>
  </header>
  <section class="entry">
  <?php
  if(isset($_POST["name"]))
  {
  include("conection.php");
$sql="INSERT INTO contact (name, emailid, contactno, subject, message) VALUES ('$_POST[name]','$_POST[email]','$_POST[contact]','$_POST[subject]','$_POST[message]')";
if (!mysql_query($sql,$con))
  {
  die('Error in mysql: ' . mysql_error());
  }
  else
  {
echo "Mail sent Successfully...";
  }
  }
  else
  {
	  ?>
  
<form name="form1" method="post" action="contact.php" id="formID">
            <label for="name">
             <h4>Your Name: (Required)</h4>
          </label>
          <br />
   <p class="textfield">
  
     <input name="name" id="grp_reg" value="" size="22" tabindex="1" type="text" class="validate[required,custom[onlyLetterSp]] text-input" />
   </p><br />
             <label for="email">
              <h4>Mail (will not be published) </h4>
          </label>
          <br />
   <p class="textfield">
       <input name="email" id="grp_reg" value="" size="22" tabindex="2" type="text" class="validate[custom[email]] text-input">

   </p><br />
             <label for="url1">
             <h4>Contact No (Required)</h4>
          </label>
   <br /><p class="textfield">
       <input name="contact" id="grp_reg" value="" size="22" tabindex="3" type="text" class="validate[required,custom[phone]] text-input">

   </p><br />
             <label for="url">
             <h4>Subject (Required)</h4>
          </label>
    <br />
    <br /><p class="textfield">
       <input name="subject" id="grp_reg"value="" size="22" tabindex="3" type="text" class="validate[required] text-input">

   </p><br />
   <p>
       <h4>Message (Required)</h4>
   :</p>
   <br />
   <p class="text-area">
       <textarea name="message" id="con_address" class="validate[required]"  cols="50" rows="10" tabindex="4"></textarea>
   </p>
   <p><br />
       <input name="submit" id="submit" tabindex="5" type="image" src="images/submit.png">
       <input name="comment_post_ID" value="1" type="hidden">
   </p>
   <div class="clear"></div>
</form>
<?php
  }
  ?>
<div class="clear"></div>
</section>
</article>


</section>

</div>