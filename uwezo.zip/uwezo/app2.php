<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title>Uwezo Fund - Online Loan Application</title>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
		<!-- Begin JavaScript -->

		<script type="text/javascript" src="lib/jquery-1.3.2.min.js"></script>
		<script type="text/javascript" src="lib/jquery.tools.js"></script>
    	<script type="text/javascript" src="lib/jquery.custom.js"></script>
		<script type="text/javascript" src="lib/validate.js"></script>
<link href="images/icon.png"rel="shortcut icon" type="image" />
        <link href="styles.css" rel="stylesheet" type="text/css" media="screen" />
        <style type="text/css">
<!--
.style1 {color: #CCCCCC}
.style6 {color: #000000}
.style10 {font-weight: bold}
.style11 {font-size: large}
.style12 {color: #F0F0F0}
#Layer8 {	position:absolute;
	width:300px;
	height:115px;
	z-index:3;
	left: 16px;
	top: 12px;
}
.style13 {font-size: 14px}
-->
        </style>
</head>
<?php
session_start(); 
include("conection.php");
include("validation.php");
include 'session.inc';
if(isset($_SESSION["userid"]))
{
?>


    <body>
        <div id="bg_bubble">
        	<div id="wrap">
        		<div id="top_wrap">
        			<div id="logo">
        				<h1><span class="style10"><a href="index.html">Welcome to Uwezo Fund Loan Application Portal </a></span></h1>
                    	<div id="Layer8"><img src="images/contacts.png" width="350" height="144" style="border:inset;border-color:#0099FF"/></div>
                    	<strong><a href="#"><small>Ahadi Yetu - Kazi Kwako </small></a></strong>
                   	  <h1>&nbsp; </h1>
       			  </div>
					<div class="header"><div>
							<ul><li class="button_box style11"></li>
							  <li class="button_box style11">
							    <div id="content_bg" align="left" class="style12"><span class="style13"><a href="app1.php" >Update Application</a><a href="app1.php" >Delete Application (Nullify) </a><a href="app1.php"> Report Issue </a><a href="<?php session_destroy(); ?>" class="active"> Log Out </a></span></div>
						      </li>
							</ul>
						</div>
				  </div>
        		</div>
				<div id="content">
					<div id="content_top"></div>
					<div id="content_bg">
						<div class="content_left">
							<div class="blog_news">
								<h6>Uwezo Fund Loan Application - Youth/Women Group and Business Location</h6>
							    <div class="news_bar">
							    <div class="clear">
							      <p>&nbsp;</p>
							      <p class="style1 style6"> <span id="feedback" class="style6"><strong>Group Registration Number</strong></span> </p>
							      <form id="frmgrploc" method="post" action="grouploc.php">
                                    <fieldset>
                                    <p>
																	  <script type="text/javascript">
								  function clear() {
								  document.frmgrpinfo.grp_name.value = "";
										}
								  </script>
                                      <input id="grp_name" type="text" name="grp_reg"  alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Group Constituency</strong></span><br />
                                      <input id="grp_reg" type="text" name="grp_constituency"  alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Group County</strong></span><br />
                                      <input id="grp_reg" type="text" name="grp_county"  alt=""/>
                                    </p>
                                    
                                    <p><span class="style6"><strong>Group Ward</strong></span><br />
                                      <input id="grp_reg" type="text" name="grp_ward" value="" alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Group Location(Area Under a Chief)</strong></span><br />
                                      <input id="grp_reg" type="text" name="grp_location" value="" alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Group Sub-Location:</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_sublocation"  alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Chief/Assistant-Chief's Name</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_chiefasstname" alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Chief/Assistant-Chief's Mobile Number</strong></span></p></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_chiefasstmobile"alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Business Area(Township/Estate/Village) of the Group</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_bizarea"  alt=""/>
                                      </p>
                                    <p><span class="style6"><strong>Name of the Business Area</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_areaname"  alt=""/>
                                      </p>
                                    <p><span class="style6"><strong>Type of Landmark Nearest to the Business(Church/Mosque/Primary School)</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_nearestLandmarkType"  alt=""/>
                                      </p>
                                    <p><span class="style6"><strong>Name of Landmark Nearest to the Business</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_nearestLandmarkName"  alt=""/>
                                      </p>
                                    <p><span class="style6"><strong>Business Street/Plot Number</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_streetplotNo"  alt=""/>
                                      </p>
                                    <p><span class="style6"><strong>Type of Business(Start-up/Expansion)</strong></span></p>
                                    <p>
              <select name="grp_biztype" id="grp_option">
                <option>Choose</option>
                <option>Start-up</option>
                <option>Expansion</option>
              </select>
                                      </p>
                                    <p><span class="style6"><strong>Is the Business a joint business?</strong></span></p>
                                    <p>
              <select name="grp_jointbiz" id="grp_option">
                <option>Choose</option>
                <option>True</option>
                <option>False</option>
              </select>
                                      </p>
                                    <br />
                                        <input name="submit" type="submit" id="contact-submit" value="Submit Group and Business Location"/>
                                    </p>
                                    </p>
                                    </fieldset>
						          </form>
								  <script type="text/javascript">
								  function init() {
								  document.forms[0].onsubmit = function() {return checkValid()};
								  }
								  window.onload = init;
								  </script>
							    </div>
							  </div>
						  </div>
							<div class="blog_news">
							  <div class="clear"></div>
							</div>			
						</div>
						<div class="clear"></div>
					</div>
					<div id="content_bot"></div>
				</div>
				<div id="footer">
					<div id="footer_column">
						<div id="footer_con_bg">
							<div id="footer_con_top">
								<div id="footer_con_bot">
								
              
							<div class="clear"></div>
							<div class="button_box">
								<blockquote>
								  <blockquote>
                                    <p><a href="http://www.facebook.com"><img src="images/facebook.png" alt="" title=""/></a> 
									<a href="http://www.twitter.com"><img src="images/twitter.png" alt="" title=""/></a> 
									<a href="http://www.yahoo.com"><img src="images/yahoo.png" alt="" title=""/></a> 
									<a href="http://www.rss.com"><img src="images/rss.png" alt="" title=""/></a> 
									<a href="http://www.youtube.com"><img src="images/youtube.png" alt="" title=""/></a></p>
							            </p>
							      </blockquote>
							  </blockquote>
                        </div>
                        <div style="clear: both"></div>								
								</div>
							</div>
						</div>
					</div>
					<div id="footer_bot">
						<p>Copyright  2014. </p>
                        <!-- Please DO NOT remove the following notice --><p>Design by <a href="http://facebook.com/ktuei" title="COMP402 Computer Systems Project">Kevin Tuei, EBS1/02955/10</a></p><!-- end of copyright notice-->
					</div>
				</div>	
        	</div>
        </div>
    </body>
</html>
<?php
}
else {
echo "Please <a href='index.php'>login</a> to access the portal";
}
?>