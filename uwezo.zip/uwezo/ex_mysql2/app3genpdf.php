
<?php



require('fpdf.php');

//Connect to your database
include("../conection.php");

//Create new pdf file
$pdf=new FPDF();

//Disable automatic page break
$pdf->SetAutoPageBreak(false);

//Add first page
$pdf->AddPage();
//Set Header
$pdf->title = 'Uwezo Loan Application Portal - Group Membership and Loan Report';

		
$file='logo.png';
$link='logo.png';	
$file2='coat-of-arms.png';
$link2='coat-of-arms.png';	
//Put Image

		$pdf->Header(	$pdf->Image($file, $x=null, $y=null, $w=22, $h=22, $type='', $link=''));
//set initial y axis position per page
$pdf->Image($file, $x=80, $y=null, $w=224, $h=159, $type='', $link='');
$pdf->Image($file2, $x=150, $y=null, $w=0, $h=0, $type='', $link2='');
$y_axis = 50;

//Set Row Height
$row_height = 6;

//print column titles
$pdf->SetFillColor(232,232,232);
$pdf->SetFont('Arial','B',10);
$pdf->SetY($y_axis);
$pdf->SetX(5);

$pdf->Cell(20,6,'OwnerID',1,0,'L',1);
$pdf->Cell(30,6,'OwnerName',1,0,'L',1);
$pdf->Cell(25,6,'BizNature',1,0,'L',1);
$pdf->Cell(27,6,'BizSector',1,0,'L',1);
$pdf->Cell(25,6,'IndivBizType',1,0,'L',1);
$pdf->Cell(25,6,'OwnerMobile',1,0,'L',1);
$pdf->Cell(30,6,'NextOfKin',1,0,'L',1);
$pdf->Cell(30,6,'KinRelshipType',1,0,'L',1);
$pdf->Cell(30,6,'KinMobile',1,0,'L',1);
$pdf->Cell(30,6,'Guarantor_Name',1,0,'L',1);
$pdf->Cell(30,6,'Guarantor_ID',1,0,'L',1);
$pdf->Cell(30,6,'Guarantor_Cell',1,0,'L',1);
$pdf->Cell(25,6,'LoanApplied',1,0,'L',1);
$pdf->Cell(25,6,'RepayTime',1,0,'L',1);
$pdf->Cell(35,6,'Approval',1,0,'L',1);




$y_axis = $y_axis + $row_height;

//Select the Products you want to show in your PDF file
$result= mysql_query("SELECT * FROM tblgroupmembloan ORDER BY GroupReg");

//initialize counter
$i = 0;

//Set maximum rows per page
$max = 25;



while($row2 = mysql_fetch_array($result))
{
	//If the current row is the last one, create new page and print column title
	if ($i == $max)
	{
		$pdf->AddPage();

		//print column titles for the current page
		$pdf->SetY($y_axis_initial);
		$pdf->SetX(5);

$pdf->Cell(20,6,'ID',1,0,'L',1);
$pdf->Cell(30,6,'OwnerName',1,0,'L',1);
$pdf->Cell(25,6,'BizNature',1,0,'L',1);
$pdf->Cell(27,6,'BizSector',1,0,'L',1);
$pdf->Cell(25,6,'IndivBizType',1,0,'L',1);
$pdf->Cell(25,6,'OwnerMobile',1,0,'L',1);
$pdf->Cell(30,6,'NextOfKin',1,0,'L',1);
$pdf->Cell(30,6,'KinRelshipType',1,0,'L',1);
$pdf->Cell(30,6,'KinMobile',1,0,'L',1);
$pdf->Cell(30,6,'Guarantor_Name',1,0,'L',1);
$pdf->Cell(30,6,'Guarantor_ID',1,0,'L',1);
$pdf->Cell(30,6,'Guarantor_Cell',1,0,'L',1);
$pdf->Cell(25,6,'LoanApplied',1,0,'L',1);
$pdf->Cell(25,6,'RepayTime',1,0,'L',1);
$pdf->Cell(35,6,'Approval',1,0,'L',1);
		
		//Go to next row
		$y_axis = $y_axis + $row_height;
		
		//Set $i variable to 0 (first row)
		$i = 0;
	}


$ownID =  $row2["OwnerID"];
$ownname = $row2["OwnerName"];
$biznat = $row2["BizNature"];
$bizsect= $row2["BizSector"]; 
$biztype= $row2["IndivBizType"];
$owncell=  $row2["OwnerMobile"];
$nxtkin= $row2["NextOfKin"];
$kinrelshp= $row2["KinRelshipType"];
$kincell= $row2["KinMobile"];
$guaname= $row2["GuarantorName"];
$guaID= $row2["GuarantorID"];
$guacell= $row2["GuarantorMobile"];
$loanappl= $row2["LoanApplied"];
$loanrepay= $row2["LoanRepaymentPeriod"];
$approved = $row2["Approved"];





	$pdf->SetY($y_axis);
	$pdf->SetX(5);
$pdf->Cell(20,6,$ownID,1,0,'L',1);
$pdf->Cell(30,6,$ownname,1,0,'L',1);
$pdf->Cell(25,6,$biznat,1,0,'L',1);
$pdf->Cell(27,6,$bizsect,1,0,'L',1);
$pdf->Cell(25,6,$biztype,1,0,'L',1);
$pdf->Cell(25,6,$owncell,1,0,'L',1);
$pdf->Cell(30,6,$nxtkin,1,0,'L',1);
$pdf->Cell(30,6,$kinrelshp,1,0,'L',1);
$pdf->Cell(30,6,$kincell,1,0,'L',1);
$pdf->Cell(30,6,$guaname,1,0,'L',1);
$pdf->Cell(30,6,$guaID,1,0,'L',1);
$pdf->Cell(30,6,$guacell,1,0,'L',1);
$pdf->Cell(25,6,$loanappl,1,0,'L',1);
$pdf->Cell(25,6,$loanrepay,1,0,'L',1);
$pdf->Cell(35,6,$approved,1,0,'L',1);

	//Go to next row
	$y_axis = $y_axis + $row_height;
	$i = $i + 1;
}

mysql_close();

//Send file
$pdf->Output();
?>
