<div style="border:1px solid #000;">
	circuit: <?=$sb['content']?>
</div>