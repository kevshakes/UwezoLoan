<?php
switch ($sb['page']) {
	case "index":
		$sb['title'] = "Home - " . $sb['title'];
		break;
	case "request":
		$sb['useTemplate'] = false;
		break;
	default:
}
?>