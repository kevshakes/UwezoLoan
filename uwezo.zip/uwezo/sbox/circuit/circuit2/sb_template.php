<div style="border:1px solid #000;">
	circuit2: <?=$sb['content']?>
</div>