 <?php
	// USED IN TEMPLATE, IDEALLY YOU CAN ADJUST/APPEND TO THIS IN THE sb_switch.php FILE
	$sb['title'] = "Uwezo Loan Application Portal";
	
	// GENERAL PREFERENCES
	$sb['errorPage'] = "error404"; // this page will be included off the ROOT (not the circuit) if someone types in an incorrect page address.
	
	// ENABLE/DISABLE INCLUSION FUNCTIONALITY, IDEALLY YOU CAN ADJUST THESE SETTINGS IN THE sb_switch.php FILE FOR INDIVIDUAL PAGES
	$sb['useTemplate'] = true;
	$sb['useController'] = true;
	$sb['useModel'] = true;
	$sb['useView'] = true;
	
	// AUTHENTICATION
	$sb['useAuthentication'] = true; // turn on/off authentication (if "false" then it ignores the rest of the authentication variables)
	$sb['hasAuthentication'] = isSet($_SESSION['applicant']); // what variable to check if it exists (such as a session that only exists if they're "logged in")
	$sb['noAuthentication'] = array("index.htm","login_post.htm","register.php"); // the array of pages you should only be able to access without authentication
	$sb['noAuthenticationRedirect'] = "index.htm?error=authentication"; // you will be redirected here if you attempt to access an internal page that you do not have authentication to
	$sb['authenticationRedirect'] = array("index.htm","login_post.htm","register.php");// if you are authenticated and attempt to access a non-authenticated page, redirect to here (such as the login page)
?>