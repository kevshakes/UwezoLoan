<?php
session_start();

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title>Uwezo Fund - Online Loan Application</title>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
		<!-- Begin JavaScript -->

		<script type="text/javascript" src="../view/lib/jquery-1.3.2.min.js"></script>
		<script type="text/javascript" src="../view/lib/jquery.tools.js"></script>
    	<script type="text/javascript" src="../view/lib/jquery.custom.js"></script>
		<script type="text/javascript" src="../view/lib/validate.js"></script>
<link href="../view/images/icon.png"rel="shortcut icon" type="image" />
        <link href="../view/styles.css" rel="stylesheet" type="text/css" media="screen" />
        <style type="text/css">
<!--
.style1 {color: #CCCCCC}
.style6 {color: #000000}
.style10 {font-weight: bold}
.style11 {font-size: large}
.style12 {color: #F0F0F0}
#Layer8 {	position:absolute;
	width:300px;
	height:115px;
	z-index:3;
	left: 16px;
	top: 12px;
}
.style13 {font-size: 14px}
-->
        </style>
</head>

<?php

	include("../view/validation.php");
include("../view/conection.php");
$result1 = mysql_query("SELECT * FROM tblgroupbizloc  where GroupReg='$_GET[slid]'");
$chk = $_GET['slid'];
  while($roww = mysql_fetch_array($result1))
  {
$regno = $roww["GroupReg"];

	}
if($regno!=$chk)
{
$sql1="INSERT INTO tblgroupbizloc (GroupReg) VALUES
('$_GET[slid]')";
if (!mysql_query($sql1,$con))
  {
  die('Error: ' . mysql_error());
  }
}
$name = "";
$date= "";
$reg= "";
$twn= ""; 
$bankacc= "";
$bank= "";
$bankbranch= "";
$postcode= "";
$address= "";
$malememb = "";
$femalememb = "";
$disabmemb = "";
$totalmemb= "";

$result = mysql_query("SELECT * FROM tblgroupinfo");


if(isset($_POST["button2"]))
{	

$sql="UPDATE tblgroupinfo SET GroupName='$_POST[grp_name]', 		GroupDateOfReg='$_POST[grp_date]',GroupTown='$_POST[grp_town]',GroupBankAcc='$_POST[grp_bankac]', 		GroupBank='$_POST[grp_bank]',GroupBankBra='$_POST[grp_bankbra]',	GroupPostCode='$_POST[grp_postcode]',GroupAddress='$_POST[grp_address]',MaleMemb='$_POST[grp_malememb]',FemaleMemb='$_POST[grp_femalememb]',DisabMemb='$_POST[grp_disabmemb]' WHERE GroupReg='$_POST[grp_reg]'";
$reg = $_POST['grp_reg'];
if (!mysql_query($sql,$con))
  {
  
  die('Error: ' . mysql_error());
  }
  else
  {
	  echo "Group Information Submitted Successfully...";
  }
header("Location: applicant1.php?view=applicantdetails&slid=$reg");
}

if($_GET["view"] == "applicantdetails")
{
$result = mysql_query("SELECT * FROM tblgroupinfo where GroupReg='$_GET[slid]'");	
  while($row = mysql_fetch_array($result))
  {
$name =  $row["GroupName"];
$reg = $row["GroupReg"];
$date= $row["GroupDateOfReg"];
$twn= $row["GroupTown"]; 
$bankacc= $row["GroupBankAcc"];
$bank=  $row["GroupBank"];
$bankbranch= $row["GroupBankBra"];
$postcode= $row["GroupPostCode"];
$address= $row["GroupAddress"];
$malememb = $row["MaleMemb"];
$femalememb = $row["FemaleMemb"];
$disabmemb = $row["DisabMemb"];
$totalmemb = $row["MaleMemb"] + $row["FemaleMemb"] + $row["DisabMemb"];
	}
}


$result1 = mysql_query("SELECT * FROM tblgroupbizloc");




?>

    <body>
        <p>&nbsp;</p>
        <div id="content_bg">
       	  <div id="wraps">
        		<div id="top_wrap">
        			<div id="logo">
        				<h1><span class="style10"><a href="../view/index.html">Welcome to Uwezo Fund Loan Application Portal </a></span></h1>
                    	<div id="Layer8"><img src="../view/images/contacts.png" width="350" height="144" style="border:inset;border-color:#0099FF"/></div>
                    	<strong><a href="#"><small>Ahadi Yetu - Kazi Kwako </small></a></strong>
                    	<h1>&nbsp; </h1>
       			  </div>
					<div class="header"><div>
							<ul><li class="button_box style11"></li>
							  <li class="button_box style11">
							    <div id="content_bg" align="left" class="style12"><span class="style13">

                                <a href="../view/applicant2.php?view=applicantdetails&amp;slid=<?php echo $reg; ?>" >Group Location </a><a href="../view/approvalnotice.php?view=0&amp;slid=<?php echo $reg; ?>"> Loan Approvals</a>
                                                                <a href="../view/app1.php" >Finalize Application</a>
                                <a href="logout.php" class="active"> Log Out </a></span></div>
						      </li>
							</ul>
						</div>
				  </div>
        		</div>
				<div id="content">
					<div id="content_top"></div>
					<div id="content_bg">
						<div class="content_left">
							<div class="blog_news">
								<h6>Uwezo Fund Loan Application - Youth/Women Group Information </h6>
							    <div class="news_bar">
							    <div class="clear">
							      <p>&nbsp;</p>
							      <p class="style1 style6"> <span id="feedback" class="style6"><strong>Group Name</strong></span> </p>
							      <form name ="form1"id="formID" method="post" action="applicant1.php">

                                    <fieldset>
                                    <p>

																	
                                      <input id="grp_name" type="text" name="grp_name" class="validate[required,custom[onlyLetterSp]] text-input" alt="" value="<?php echo $name; ?>"/>
                                    </p>
                                    <p><span class="style6"><strong>Registration No/Serial No:</strong></span><br />
                                      <input id="grp_reg" type="text" name="grp_reg" class="validate[required]text-input"  alt="" value="<?php echo $reg; ?>"/>
                                    </p>
                                    <p><span class="style6"><strong>Date of Registration:</strong></span><br />
    <script src="../view/datetimepicker_css.js"></script>

    <input type="Text" name="grp_date" id="textdob" class="validate[required,[date]]text-input"  maxlength="25" size="25" value="<?php echo $date; ?>"/>
        <img src="../view/images/cal.gif" onclick="javascript:NewCssCal ('textdob')"  style="cursor:pointer"/>
        <p><span class="style6"><strong>Number of Male Members:</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_malememb" class="validate[required,custom[onlyNumberSp]] text-input" alt="" value="<?php echo $malememb; ?>"/>
                                             <p><span class="style6"><strong>Number of Female Members:</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_femalememb" class="validate[required,custom[onlyNumberSp]] text-input" alt="" value="<?php echo $femalememb; ?>"/>
                                             <p><span class="style6"><strong>Number of Disabled Members:</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_disabmemb" class="validate[required,custom[onlyNumberSp]] text-input" alt="" value="<?php echo $disabmemb;  ?>" />
                                             <p><span class="style6"><strong>Total Number of Members:</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_totalmemb" class="validate[required,custom[onlyNumberSp]] text-input" alt="" value="<?php echo $totalmemb; ?>" onfocus="<?php $totalmemb = $_GET['grp_femalememb']+ $_GET['grp_malememb'] +$_GET['grp_disabmemb'];?>"/>
        
                                    <p><span class="style6"><strong>Town:</strong></span></p>
                                    <p>
									   <input id="grp_reg" type="text" name="grp_town" class="validate[required] text-input" alt="" value="<?php echo $twn; ?>" />
                                    </p>
                                    <p><span class="style6"><strong>Bank Account:</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_bankac" class="validate[required,custom[onlyNumberSp]] text-input" alt="" value="<?php echo $bankacc; ?>"/>
                                    </p>
                                    <p><span class="style6"><strong>Bank Name:</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_bank" class="validate[required,custom[onlyLetterSp]] text-input" alt="" value="<?php echo $bank; ?>"/>
                                    </p>
                                    <p><span class="style6"><strong>Bank Branch</strong></span></p></p>
                                    <p>
                                      <input id="grp_reg" class="validate[required,custom[onlyLetterSp]] text-input" type="text" name="grp_bankbra"alt="" value="<?php echo $bankbranch; ?>"/>
                                    </p>
                                    <p><span class="style6"><strong>Postal Code:</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_postcode"  class="validate[required,custom[onlyNumberSp]] text-input"alt="" value="<?php echo $postcode; ?>"/>
                                    </p>
                                    <p><span class="style6"><strong>Postal Address</strong></span><br />
                                        <input id="con_address" name="grp_address" class="validate[required] text-input" cols="0" rows="0" value="<?php echo $address; ?>" />
                                      <br />
                                                                                <input name="button2" type="submit" id="contact-submit" value="Update Group Information"/>
                                    </p>
                                    </p>
                                    </fieldset>
						          </form>
							    </div>
							  </div>
						  </div>
							<div class="blog_news">
							  <div class="clear"></div>
							</div>			
						</div>
						<div class="clear"></div>
					</div>
					<div id="content_bot"></div>
				</div>
				<div id="footer">
					<div id="footer_column">
						<div id="footer_con_bg">
							<div id="footer_con_top">
								<div id="footer_con_bot">
								
              
							<div class="clear"></div>
							<div class="button_box">
                 
						    <blockquote>
								  <blockquote>
                                    <p><a href="http://www.facebook.com"><img src="../view/images/facebook.png" alt="" title=""/></a> 
									<a href="http://www.twitter.com"><img src="../view/images/twitter.png" alt="" title=""/></a> 
									<a href="http://www.yahoo.com"><img src="../view/images/yahoo.png" alt="" title=""/></a> 
									<a href="http://www.rss.com"><img src="../view/images/rss.png" alt="" title=""/></a> 
									<a href="http://www.youtube.com"><img src="../view/images/youtube.png" alt="" title=""/></a></p>
							            </p>
							      </blockquote>
							  </blockquote>
                        </div>
                        <div style="clear: both"></div>								
								</div>
							</div>
						</div>
					</div>
					<div id="footer_bot">
						<p>Copyright  2014. </p>
                        <!-- Please DO NOT remove the following notice --><p>Design by <a href="http://facebook.com/ktuei" title="COMP402 Computer Systems Project">Kevin Tuei, EBS1/02955/10</a></p><!-- end of copyright notice-->
					</div>
				</div>	
        	</div>
        </div>
    </body>
</html>
<?php
	
//}
//else {

	
//echo "<h3'> <a href='index.php'>Please login to access the portal</a> </h3>";
//}
?>