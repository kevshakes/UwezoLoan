<?php
include("head.php");
?>
								    <div align="center" id="menu"class="style12"><span class="style13"><a href="grouploc.php" ><h3>Previous(2/3):Group Location</h3> </a><a href="#"><h3>~~~~~~~~</h3>
								    </a></span>
								      <p class="style13"><a href="groupreg.php"><h3> First(1/3): Group Information</h3></a><a href="#"><h3>~~~~~~~~</h3></a></p>
                                      								      <p class="style13"><a href="../contactview.php?view=0&slid=0"><h3> Check Enquiry Messages</h3></a><a href="#"><h3>~~~~~~~~</h3></a></p>
                                                                          <a href="approvaltest.php?view=0&slid=0"> <h3>Approve Applications</h3></a></p>
                                      
</div>

<?php
//attempt connection to MySQL Database
$mysqli = new mysqli("localhost","root","","uwezo");
if ($mysqli === false) {
die("ERROR: Could not connect to database. " . mysqli_connect_error());
}

$submitted = false;
//if form submitted
//process form input
if(isset($_POST['submit'])) {
//open message block
$submitted = true;
echo '<div id="message">';

//retrieve and check input values
$inputError = false;
if (empty($_POST['own_id'])) {
echo 'ERROR: Please Enter a Valid National ID of Owner/Member';
$inputError = true;

} else {
$id = $mysqli->escape_string($_POST['own_id']);
}

if ($inputError != true && empty($_POST['own_name'])) {
echo 'ERROR: Please Enter a Valid Owner/Member Name';
$inputError = true;
} else {
$ownname = $mysqli->escape_string($_POST['own_name']);
}

if ($inputError != true && empty($_POST['biz_nat'])) {
echo 'ERROR: Please Enter a valid Nature of Business';
$inputError = true;
} else {
$biznat = $mysqli->escape_string($_POST['biz_nat']);
}

if ($inputError != true && empty($_POST['biz_sect'])) {
echo 'ERROR: Please Enter a valid Business Sector';
$inputError = true;
} else {
$bizsect = $mysqli->escape_string($_POST['biz_sect']);
}

if ($inputError != true && empty($_POST['indivbiz_type'])) {
echo 'ERROR: Please Enter a valid type of business type of the Owner/Mobile';
$inputError = true;
} else {
$biztype = $mysqli->escape_string($_POST['indivbiz_type']);
}

if ($inputError != true && empty($_POST['own_mobile'])) {
echo 'ERROR: Please Enter a valid Mobile Number of the Owner';
$inputError = true;
} else {
$ownmobile = $mysqli->escape_string($_POST['own_mobile']);
}
if ($inputError != true && empty($_POST['nextof_kin'])) {
echo 'ERROR: Please Enter a valid Name of the Next of Kin ';
$inputError = true;
} else {
$kinname = $mysqli->escape_string($_POST['nextof_kin']);
}
if ($inputError != true && empty($_POST['kin_relshiptype'])) {
echo 'ERROR: Please Enter a valid type of Relationship with Next of Kin ';
$inputError = true;
} else {
$kintype = $mysqli->escape_string($_POST['kin_relshiptype']);
}
if ($inputError != true && empty($_POST['kin_mobile'])) {
echo 'ERROR: Please Enter a valid Mobile Number of the Next of Kin';
$inputError = true;
} else {
$kinmobile = $mysqli->escape_string($_POST['kin_mobile']);
}

if ($inputError != true && empty($_POST['guar_name'])) {
echo 'ERROR: Please Enter a valid Name of the Guarantor(s)';
$inputError = true;
} else {
$guarname = $mysqli->escape_string($_POST['guar_name']);
}

if ($inputError != true && empty($_POST['guar_id'])) {
echo 'ERROR: Please Enter a valid National ID of the Guarantor(s)';
$inputError = true;
} else {
$guarid= $mysqli->escape_string($_POST['guar_id']);
}

if ($inputError != true && empty($_POST['guar_mobile'])) {
echo 'ERROR: Please Enter a valid Mobile Number of the Guarantor(s)';
$inputError = true;
} else {
$guarmobile= $mysqli->escape_string($_POST['guar_mobile']);
}

if ($inputError != true && empty($_POST['loan_appl'])) {
echo 'ERROR: Please Enter a valid Name for the Landmark where the Business of the Group is located';
$inputError = true;
} else {
$loanappl = $mysqli->escape_string($_POST['loan_appl']);
}

$period = $mysqli->escape_string($_POST['loan_repay']);
if ($inputError != true && empty($_POST['loan_repay'])) {
echo 'ERROR: Please Enter a valid Loan Repayment Period';
if ($period > 24){echo 'ERROR: The Maximum Loan repayment period is 24';}
$inputError = true;
} else {
$loanrepay = $mysqli->escape_string($_POST['loan_repay']);
}

if ($inputError != true && empty($_POST['comments'])) {
echo 'ERROR: Please Enter a comment and if you dont have, type "NO COMMENTS"';
$inputError = true;
} else {
$comments= $mysqli->escape_string($_POST['comments']);
}


//add values to database using INSERT query
if ($inputError != true) {
$sql = "INSERT INTO tblgroupmembloan(OwnerID, OwnerName, BizNature, BizSector, IndivBizType, OwnerMobile, NextOfKin, KinRelshipType, KinMobile, GuarantorName, GuarantorID, GuarantorMobile, LoanApplied, LoanRepaymentPeriod, Comments) VALUES ('$id','$ownname','$biznat','$bizsect', '$biztype', '$ownmobile','$kinname','$kintype','$kinmobile','$guarname','$guarid','$guarmobile','$loanappl,'$loanrepay')";
		if ($mysqli->query($sql) === true) {
		echo 'New Record Added with ID: ' .$id;
		} else {
		echo "ERROR: Could not execute query: $sql. " . $mysqli->error;
		}
	}
	//close message block
	echo '</div>';
	}
	if (($submitted == true && $inputError == false) || $submitted == false) {
	?>
	</div>
		
	<h3> Group Membership and Loan - Submissions</h3>
        <h5>&nbsp;</h5>
	<?php
	}
	//get records
	//format as HTML table
	$sql = "SELECT OwnerID, OwnerName, BizNature, BizSector, IndivBizType, OwnerMobile, NextOfKin, KinRelshipType, KinMobile, GuarantorName, GuarantorID, GuarantorMobile, LoanApplied, LoanRepaymentPeriod, Comments, Approved  FROM tblgroupmembloan";
	if ($result = $mysqli->query($sql)) {
	if ($result->num_rows > 0) {
	echo "<table border='1'>\n";
	echo "<tr class=\"heading\">\n";
	echo "<td>#</td>\n";
	echo "<td>OwnerID</td>\n";
	echo "<td>OwnerName</td>\n";
	echo "<td>BizNature</td>\n";
	echo "<td>BizSector</td>\n";
	echo "<td>IndivBizType</td>\n";
	echo "<td>OwnerMobile</td>\n";
	echo "<td>NextOfKin</td>\n";
	echo "<td>KinRelshipType</td>\n";
	echo "<td>KinMobile</td>\n";
	echo "<td>Guarantor_Name</td>\n";
	echo "<td>Guarantor_ID</td>\n";
	echo "<td>Guarantor_Mobile</td>\n";
	echo "<td>LoanApplied</td>\n";
	echo "<td>LoanRepaymentPeriod</td>\n";
	echo "<td>Comments</td>\n";
	echo "<td>Approval</td>\n";
	
	echo "</tr>\n";
	$i =1;
	while ($row=$result->fetch_object()) {
	
	echo "<tr>\n";
	
	echo "<td>" .  $i . "</td>\n";
	echo "<td>" .  $row->OwnerID . "</td>\n";
	echo "<td>" .  $row->OwnerName . "</td>\n";
	echo "<td>" .  $row->BizNature . "</td>\n";
	echo "<td>" .  $row->BizSector . "</td>\n";
	echo "<td>" .  $row->IndivBizType . "</td>\n";
	echo "<td>" .  $row->OwnerMobile . "</td>\n";
	echo "<td>" .  $row->NextOfKin. "</td>\n";
	echo "<td>" .  $row->KinRelshipType . "</td>\n";
	echo "<td>" .  $row->KinMobile . "</td>\n";
	echo "<td>" .  $row->GuarantorName . "</td>\n";
	echo "<td>" .  $row->GuarantorID . "</td>\n";
	echo "<td>" .  $row->GuarantorMobile . "</td>\n";
	echo "<td>" .  $row->LoanApplied . "</td>\n";
	echo "<td>" .  $row->LoanRepaymentPeriod . "</td>\n";
	echo "<td>" .  $row->Comments . "</td>\n";
	echo "<td>" .  $row->Approved . "</td>\n";

	echo "</tr>\n";
	 $i++;
	}
	echo "</table>";
	$result->close();
	} else {
	echo "No Group Membership and Loan details in database.";
	}
	}else {
	echo "ERROR: Could not execute query: $sql. " . $mysqli->error;
	}
	//close connection
	$mysqli->close();
	?>
</body>
</html>
