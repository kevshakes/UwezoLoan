<?php
include("validation.php");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>

        <title>Uwezo Fund - Kenya Government</title>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
		<!-- Begin JavaScript -->

		<script type="text/javascript" src="lib/jquery-1.3.2.min.js"></script>
		<script type="text/javascript" src="lib/jquery.tools.js"></script>
    	<script type="text/javascript" src="lib/jquery.custom.js"></script>

        <link href="styles.css" rel="stylesheet" type="text/css" media="screen" />
        <style type="text/css">
<!--
.style1 {color: #000000}
-->
        </style>
</head>
    <body>
        <div id="bg_bubble">
        	<div id="wrap">
        		<div id="top_wrap">
        			<div id="logo">
        				<h1><a href="index.html">Uwezo fund - Kenya Government </a></h1>
               	  <a href="#"><small>Ahadi Yetu - Kazi Kwako </small></a></div>
					<div class="header"><div id="menu">
							<ul>
			                	<li><a href="index.html" >Home</a></li>
								<li><a href="aboutus.html">About Us</a></li>
			                    <li><a href="faqs.html">FAQs</a></li>
			                    <li><a href="gallery.html">Photo Gallery</a></li>	
			                    <li><a href="contact.php" class="active">Contact Us</a></li>
			                </ul>
						</div>
						<div id="header_img">
							<div id="slider_bg">
								<div class="waveshow">
									<img src="images/uwezo_header.png" alt="" width="660" height="338" title="Uwezo Fund" />
									<img src="images/s1.jpg" alt="" width="660" height="338" title="H.E. Uhuru Kenyatta, the President of the Republic of Kenya at the Uwezo Fund Launch" />
									<img src="images/s2.jpg" alt="" width="660" height="338" title="Launch of the Uwezo Fund" />
									<img src="images/s3.jpg" alt="" width="660" height="338" title="Madam Ann Waiguru at the Launch of the Uwezo Fund" />
									<img src="images/s4.jpg" alt="" width="660" height="338" title="Uwezo Fund Contacts" />
									<img src="images/s5.jpg" alt="" width="660" height="338" title="Chics project" />
									<img src="images/s6.jpg" alt="" width="660" height="338" title="Seedlings project" />
									<img src="images/s7.jpg" alt="" width="660" height="338" title="Launch of the Uwezo Fund" />
									<img src="images/s8.jpg" alt="" width="660" height="338" title="Exhibitors at the launch of the Uwezo Fund" />
									<img src="images/s9.jpg" alt="" width="660" height="338" title="Fish Pond Project" />
									<img src="images/s10.jpg" alt="" width="660" height="338" title="Deputy President William Ruto at the launch" />								</div> 
								<!-- waveshow -->
							</div> <!-- slider_bg -->
						</div>
					</div>
        		</div>
				<div id="content">
					<div id="content_top"></div>
					<div id="content_bg">
                    
						<div class="content_left">
							<h6>Contact Us</h6>
                            
							<div id="ajax_form">
<form>
<br><br>
  <?php
  if(isset($_POST["name"]))
  {
  include("conection.php");
$sql="INSERT INTO contact (name, emailid, contactno, subject, message) VALUES ('$_POST[name]','$_POST[email]','$_POST[contact]','$_POST[subject]','$_POST[message]')";
if (!mysql_query($sql,$con))
  {
  die('Error in mysql: ' . mysql_error());
  }
  else
  {
echo "Mail sent Successfully...";
  }
  }
  else
  {
	  ?>
<div id="ajax_form_header">Contact Uwezo Team</div>
<br>
<table align="center" border="0" cellpadding="4" cellspacing="0" width="350">
  <tbody><tr> 
    <td><label>Your Name:</label></td>
    <td>       <input name="name" id="name" value="" size="22" tabindex="1" type="text" class="validate[required,custom[onlyLetterSp]] text-input"></td>
  </tr>
  <tr><td><br><br></td></tr>
  <tr> 
    <td><label>Your Email:</label></td>
    <td><input name="email" id="email" value="" size="22" tabindex="2" type="text" class="validate[required,custom[email]] text-input"></td>
  </tr>
  <tr><td><br><br></td></tr>
  <tr> 
    <td><label>Your Subject:</label></td>
    <td><input id="subject" style="width:100%" type="text"></td>
  </tr>
  <tr><td><br><br></td></tr>
  <tr> 
      <td><label>Mobile Contact:</label></td>
    <td> <input name="contact" id="contact" value="" size="22" tabindex="3" type="text" class="validate[required,custom[phone]] text-input"></td>
  </tr>
  <tr><td><br><br></td></tr>
  <tr> 
    <td colspan="2">
    	<label>Your Message:</label><br><br>
    	<textarea name="body" style="width:100%;height:160px" id="body"></textarea>
    </td>
  </tr>
  <tr align="center"> 
    <td colspan="2">       <input name="submit" id="submit" tabindex="5" type="image"  style="width:25%" src="images/submit.png">
    <input name="comment_post_ID" value="1" type="hidden"></td>
  </tr>
</tbody></table>
</form>
<?php
  }
  ?>
  <br>     </div>
    </div>
										
						</div>
						<div class="content_right">
							<h6>Quisque Tempor</h6>
							<div class="contact_news">
								<p><a href="#">Quisque tempor, tellus in placerat feugiat, metus massa pellentesque elit, id semper odio enim quis tellus.</a><br />
								Donec urna ipsum, bibendum eget malesuada nec, semper ut libero. Vestibulum id felis sem, quis convallis lacus. Donec lacinia mi vitae metus cursus sed mollis ligula mattis. <br />
								Cras convallis iaculis erat, et venenatis turpis gravida non. Ut vehicula leo tempor dui scelerisque aliquam eget id odio. Praesent euismod egestas porta. Nulla 
								</p>
								<div class="read2">
									<a href="#">read more</a>
								</div>
								<div class="clear"></div>
							</div>
							
							<h6>Meet Our Company</h6>
							<div class="contact_news">
								<div class="pad_left" style="background: url(images/house.jpg) no-repeat left center">
                                	1234 Some Street, Brooklyn, NY 11201
	                            </div>
	                            <div class="pad_left" style="background: url(images/phone.jpg) no-repeat left center">
	                                Phone:  1(234) 567 8910
	                            </div>
	                            <div class="pad_left">
	                                Fax: 1(234) 567 8910
	                            </div>
	                            <div class="pad_left" style="background: url(images/contact_icon.jpg) no-repeat left center">
	                                General: companyname@yahoo.com
	                            </div>
								<div class="pad_left">
	                                Support: support@yahoo.com
	                            </div>
							</div>
							
							
							
						</div>
						
						
						
						
						
						
						
						
						<div class="clear"></div>
					</div>
					<div id="content_bot"></div>
				</div>
				<div id="footer">
					<div id="footer_column">
						<div id="footer_con_bg">
							<div id="footer_con_top">
								<div id="footer_con_bot">
									<div class="foot_col1">
										<h3>Contact Information</h3>
                            <div class="pad_left" style="background: url(images/phone.png) no-repeat left center">
                                Phone: 020 222 333 </div>
                            <div class="pad_left">
                                Mobile: +254 712 838653 </div>
                            <div class="pad_left" style="background: url(images/contact.png) no-repeat left center">
                                E-mail:uwezofund@yahoo.com
                            </div>
                        </div>
                        
                        
                        <div class="foot_col4">
                          <div class="clear">
							  <div class="clear"></div>
							  <div class="button_box">
                                <blockquote>
                                  <blockquote>
                                    <p><a href="http://www.facebook.com/uwezofund"><img src="images/facebook.png" alt="" title=""/></a> 
									<a href="http://www.twitter.com/uwezofund"><img src="images/twitter.png" alt="" title=""/></a> 
									<a href="http://www.yahoo.com"><img src="images/yahoo.png" alt="" title=""/></a> 
									<a href="http://www.rss.com"><img src="images/rss.png" alt="" title=""/></a> 
									<a href="http://www.youtube.com"><img src="images/youtube.png" alt="" title=""/></a></p>
                                  </blockquote>
                                </blockquote>
						      </div>
						  </div>
							</div>
                        <div style="clear: both"></div>								
								</div>
							</div>
						</div>
					</div>
					<div id="footer_bot">
						<p><img src="images/coat-of-arms.png" alt="Ministry of Devolution and Planning" width="278" height="127" align="right" /></p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p class="style1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Copyright  © 2014. </p>
						<span class="style1">
						<!-- Please DO NOT remove the following notice -->
                        </span>
						<p><span class="style1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Design by <a href="http://facebook.com/ktuei" title="">Kevin Tuei, EBS1/02955/10</a></span></p>
                        <!-- end of copyright notice-->
				  </div>
				</div>	
        	</div>
        </div>
    </body>
</html>
