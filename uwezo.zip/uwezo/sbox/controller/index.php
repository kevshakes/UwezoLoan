<?php
include("config.php");
include("modal.php");
$log = "";
$pwdmd5  = "";

if(isset($_SESSION["userid"]))
{
	if($_SESSION["type"]=="admin")
	{
header("Location: applicant1.php?view=applicantdetails&slid=$reg");
	}
	else
	{	
	header("Location: index.php");
	}
}

if(isset($_POST["username"]) && isset($_POST["pass"]) )
{
			$user_id= $_POST["username"]; 
		$pass= $_POST["pass"]; 
		$login= $_POST['login']; 
		$selected_user_type= $_POST['user_type'];
				if($login)
			{
				switch($selected_user_type)
					{
						case "Applicant":
$result = mysql_query("SELECT * FROM applicant WHERE user='$_POST[username]'");
$result1 = mysql_query("SELECT * FROM tblgroupinfo WHERE GroupReg='$_POST[username]'");
while($row = mysql_fetch_array($result))
  {
$pwdmd5 = $row["pass"];

  }
 while($row = mysql_fetch_array($result1))
  {
$reg = $row["GroupReg"];
  }

if(md5($_POST["pass"])==$pwdmd5)
{
	$_SESSION['userid'] = $_POST["username"];
	$_SESSION['type'] = 'applicant';
	header("Location: applicant1.php?view=applicantdetails&slid=$reg");
}
else
{
$log =  "Login failed.. Please try again..";
}
break;
							
						case "Admin":
						$result = mysql_query("SELECT * FROM admin WHERE user='$_POST[username]'");

while($row = mysql_fetch_array($result))
  {

$pwdmd5 = $row["pass"];

  }
if(md5($_POST["pass"])==$pwdmd5)
{
	$_SESSION['userid'] = $_POST["username"];
	$_SESSION['type'] = 'admin';
	header("Location: groupreg.php");
}
else
{
$log =  "Login failed.. Please try again..";
}
	break;
	case "select":
	$log =  "Please select a valid User Type <br>";
	break;
}
}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<link href="images/icon.png"rel="shortcut icon" type="image" />
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Loan Application Portal</title>
<style type="text/css">
<!--
#Layer1 {
	position:absolute;
	width:1014px;
	height:100px;
	z-index:1;
	left: 105px;
	top: 68px;
	background-color: #FFFFFF;
	visibility: inherit;
}
#Layer2 {
	position:absolute;
	width:610px;
	height:309px;
	z-index:2;
	left: 371px;
	top: 185px;
	background-color: #FFFFFF;
}
#Layer3 {
	position:absolute;
	width:258px;
	height:60px;
	z-index:3;
	left: 120px;
	top: 145px;
	background-color: #FFFFFF;
}
#Layer4 {
	position:absolute;
	width:834px;
	height:135px;
	z-index:3;
	left: 116px;
	top: 83px;
	background-color: #FFFFFF;
}
#Layer5 {
	position:absolute;
	width:764px;
	height:73px;
	z-index:3;
	left: 245px;
	top: 132px;
}
#Layer6 {
	position:absolute;
	width:100px;
	height:89px;
	z-index:3;
	left: -1px;
	top: -70px;
}
#Layer7 {
	position:absolute;
	width:843px;
	height:76px;
	z-index:3;
	left: 293px;
	top: 94px;
	background-color: #0000FF;
}
#Layer8 {
	position:absolute;
	width:948px;
	height:115px;
	z-index:3;
	left: 451px;
	top: 12px;
}
#Layer9 {
	position:absolute;
	width:1042px;
	height:80px;
	z-index:4;
	left: 150px;
	top: 477px;
	background-color: #0099FF;
}
#Layer10 {
	position:absolute;
	width:880px;
	height:26px;
	z-index:1;
	top: 322px;
	left: -136px;
}
.style1 {color: #0099CC}
#Layer11 {
	position:absolute;
	width:442px;
	height:35px;
	z-index:4;
	left: 101px;
	top: 245px;
}
#Layer12 {
	position:absolute;
	width:328px;
	height:20px;
	z-index:4;
	left: 145px;
	top: 27px;
}
.style2 {
	font-size: 18px;
	font-weight: bold;
	color: #FFFFFF;
}
-->
</style>
</head>

<body>
<div id="Layer2" style="background-image:url(admin/images/trial.png);background-repeat:repeat">
  <table width="615" height="309"  border="20" align="center" bordercolor="#FFFFFF" bgcolor="#6633CC"style="border-color:#FFFFFF">    
    <tr>
      <td width="465"><form id="form1" name="form1" method="post" action="">
        <div id="Layer12"> 
          <div align="center" class="style2">Login or Register to Access Portal </div>
        </div>
        <table width="281" border="0" align="center" cellpadding="5" cellspacing="3">
          
          <tr>
            <td width="87"><div align="right"><strong>User </strong></div></td>
            <td width="165"><label>
              <select name="user_type" id="user">
                <option>select</option>
                <option>Admin</option>
                <option>Applicant</option>
              </select>
            </label></td>
          </tr>
          <tr>
            <td><div align="right">
              <p>
            <strong> Registration Number</strong></p>
            </div></td>
            <td><label>
              <input name="username" type="text" id="username" size="25" />
            </label></td>
          </tr>
          <tr>
            <td><div align="right"><strong>Password</strong></div></td>
            <td><label>
              <input name="pass" type="password" id="pass" size="25" />
            </label></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td><input name="login" type="submit" id="login" value="Login" /></td>
          </tr>
        </table>
            <div id="Layer11"><?php echo $log;?> <?php echo "\nNot having an Account? <a href='#' onClick='openregister(); return false'>Register</a> to access the portal";?> </div>
      </form>      </td>
    </tr>
  </table>
  <div id="Layer10">
    <div align="center" class="style1">&copy; 2014 Kevin Tuei, EBS1/02955/10, Computer Systems Project </div>
  </div>
</div>
<div id="Layer8"><img src="images/contacts.png" width="350" height="144" style="border:inset;border-color:#0099FF"/></div>
</body>
</html>
