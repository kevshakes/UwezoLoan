		<script type="text/javascript" src="lib/jquery-1.3.2.min.js"></script>
		<script type="text/javascript" src="lib/jquery.tools.js"></script>
    	<script type="text/javascript" src="lib/jquery.custom.js"></script>

        <link href="styles.css" rel="stylesheet" type="text/css" media="screen" />
        <style type="text/css">
<!--
.style1 {color: #000000}
-->
        </style>
<?php
include("sharkhead.php");
include("validation.php");
  include("conections.php");
$message = '';
$name = '';
?>
<section id="page">
<header id="pageheader" class="normalheader">
<h2 class="sitedescription">
  </h2>
</header>
<img src='images/chukauni.png' width="209" height="159"   />
<section id="contents">

<article class="post">
  <header class="postheader">
  <h4>Welcome to Chuka University Shark Course Enquiry System</h4>
  </header>
  <section class="entry">
  <?php
  if(isset($_POST["name"]))
  {


  if($_GET["view"] == "chat")
{
$result = mysql_query("SELECT * FROM tblquestions_ans where Name='$_GET[slid]'");	
  while($row = mysql_fetch_array($result))
  {
	$name =  $row["Name"];
	$message = $row["Reply"];
		if ($message=='course'){
		$result1 = mysql_query("SELECT * FROM tblunits where Course ='$_GET[slid]'");
	  		while($row1 = mysql_fetch_array($result1))
 				 {
				$courses =  $row1["Course"];
				echo $courses;
 				 }
		}

	}
}

$sql="INSERT INTO tblquestions_ans (Name, Reply) VALUES ('$_POST[name]','$_POST[message]')";
if (!mysql_query($sql,$con))
  {
  die('Error in mysql: ' . mysql_error());
  }
  else
  {
	  $name = $_POST['name'];
	  $enq = $_POST['message'];

header("Location: shark.php?view=chat&slid=$name&qn=$enq");
  }

  }

	  ?>
  
<form name="form1" method="post" action="" id="formID">
            <label for="name">
            <?php 
			  if(($_GET["qn"])!='')
  {
			
			$results = mysql_query("SELECT * FROM tblquestions_ans where Name='$_GET[slid]'");	
  while($row = mysql_fetch_array($results))
  {
	  $name =  $row["Name"];
	  
$message = $row["Reply"];




	}

				  if ($message == 'course' || 'Courses' || 'Course' ){
					  	echo 'Hello    ' . $name . ',   you asked:<br>';
			echo  $message . ':<br>';
		$result1 = mysql_query("SELECT * FROM tblunits");
		echo 'I am glad to inform you    ' . $name . ',   that the following are the courses we offer:<br>';
	  		while($row1 = mysql_fetch_array($result1))
 				 {
				$courses =  $row1["CourseName"];
				echo $courses;
				echo '<br>';
 				 }
	  }

	  if ($message == $_GET['qn'] ){
		  //$course = $_GET['course'];
		$result1 = mysql_query("SELECT * FROM tblunits where CourseName='$_GET[qn]'");
		if($result1){
		echo 'The units offered for   ' . $_GET['qn'] . ',   are as follows:<br>';
	  		while($row1 = mysql_fetch_array($result1))
 				 {
				$units =  $row1["UnitsDetails"];
				echo $units;
				echo '<br>';
 				 }
	  }
	  }
  }
if ($message == 'x' )
{
			echo 'I am sorry to inform you    ' . $name . ',   that I cant understand what you are saying';
	}

  $name = $_GET['slid'];
			?>
             <h4>Your Name: (Required)</h4>
          </label>
          <br />
   <p class="textfield">
  
     <input name="name" id="grp_reg" value="<?php echo $name ?>" size="22" tabindex="1" type="text" class="validate[required,custom[onlyLetterSp]] text-input" />
   </p><br />


   </p><br />
   <p>
       <h4>Enquiry (Required)</h4>
   </p>
   <br />
   <p class="text-area">
       <textarea name="message" id="con_address" class="validate[required]"  cols="50" rows="10" tabindex="4" ></textarea>
   </p>
   <p><br />
       <input name="button2" id="submit" tabindex="5" type="image" src="images/submit.png">
       <input name="comment_post_ID" value="1" type="hidden">
   </p>
   <div class="clear"></div>
</form>

<div class="clear"></div>
</section>
</article>


</section>

</div>