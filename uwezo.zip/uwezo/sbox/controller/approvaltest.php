<?php
include("conection.php");
include("headz.php");
$approved = mktime();
$sign = mktime();
$approved = $approved + 7200;
$apprvtimestamp = date('d M Y h:i:s', $approved);
if(isset($_POST["button"]))
{
header ("location:groupmembloan.php");
}


if($_GET["view"] == "approve")
{
	
mysql_query("UPDATE tblgroupmembloan SET Approved='$apprvtimestamp:$_GET[slid]:$sign' WHERE OwnerID ='$_GET[slid]'");
}
$result = mysql_query("SELECT * FROM tblgroupmembloan");
?>
<section id="page">
<header id="pageheader" class="normalheader">
<h2 class="sitedescription">
 </h2>
</header>

<section id="contents">

<article class="post">
  <header class="postheader"><img src='images/logo.png' width="224" height="159"   />
  <h2>    Application Approval Process</h2>
  </header>
  <section class="entry">
  <form name="form2" method="post" action="">
<table width="485" border="1">
  <tr>
    <td width="56"><strong>Process#</strong></td>
	<td width="205"><strong>OwnerID</strong></td>;
<td width="205"><strong>OwnerName</strong></td>
<td width="205"><strong>BizNature</strong></td>
	<td ><strong>BizSector</strong></td>
	<td ><strong>IndivBizType</strong></td>
	<td ><strong>OwnerMobile</strong></td>
	<td ><strong>NextOfKin</strong></td>
	<td ><strong>KinRelshipType</strong></td>
	<td ><strong>KinMobile</strong></td>
	<td ><strong>Guarantor_Name</strong></td>
	<td ><strong>Guarantor_ID</strong></td>
	<td ><strong>Guarantor_Mobile</strong></td>
	<td ><strong>LoanApplied</strong></td>
	<td ><strong>LoanRepaymentPeriod</strong></td>
	<td ><strong>Approval</strong></td>
  </tr>
  <?php
	  $i =1;
  while($row = mysql_fetch_array($result))
  {
  echo "<tr>";
  echo "<td>&nbsp";
  ?>
  <a href="approvaltest.php?view=approve&slid=<?php echo $row["OwnerID"]; ?>&view=approve"><img src='../images/icon.png' width='32' height='32'  onclick="return confirm('Approve Applicant with ID <?php echo $row["OwnerID"]; ?>?')"/></a>
  <?php
  echo  $i . " </td>";
     	  //echo "<td>&nbsp;" . $row['name'] . "</td>";
	echo "<td>" .  $row['OwnerID'] . "</td>\n";
	echo "<td>" .  $row['OwnerName'] . "</td>\n";
	echo "<td>" .  $row['BizNature'] . "</td>\n";
	echo "<td>" .  $row['BizSector'] . "</td>\n";
	echo "<td>" .  $row['IndivBizType'] . "</td>\n";
	echo "<td>" .  $row['OwnerMobile'] . "</td>\n";
	echo "<td>" .  $row['NextOfKin'] . "</td>\n";
	echo "<td>" .  $row['KinRelshipType'] . "</td>\n";
	echo "<td>" .  $row['KinMobile'] . "</td>\n";
	echo "<td>" .  $row['GuarantorName'] . "</td>\n";
	echo "<td>" .  $row['GuarantorID'] . "</td>\n";
	echo "<td>" .  $row['GuarantorMobile'] . "</td>\n";
	echo "<td>" .  $row['LoanApplied'] . "</td>\n";
	echo "<td>" .  $row['LoanRepaymentPeriod'] . "</td>\n";
	echo "<td>" .  $row['Approved'] . "</td>\n";
  echo "</tr>&nbsp;";
  $i++;
  }
  
?>

  <tr>
    <td height="25">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
        <td>&nbsp;</td>
    <td>&nbsp;</td>
        <td>&nbsp;</td>
    <td>&nbsp;</td>
        <td>&nbsp;</td>
    <td>&nbsp;</td>
        <td>&nbsp;</td>
    <td>&nbsp;</td>
        <td>&nbsp;</td>
    <td>&nbsp;</td>
        <td>&nbsp;</td>
    <td>&nbsp;</td>
        <td>&nbsp;</td>

    

  </tr>
</table>
    </form>
  </section>
</article>


</section>

<p>&nbsp;</p>
<form name="form1" method="post" action="">
  <input type="submit" name="button" id="button" value="End Process">
</form>
