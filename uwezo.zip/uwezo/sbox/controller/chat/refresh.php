<?php
$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("chat", $con);

$result = mysql_query("SELECT * FROM message ORDER BY id DESC");


while($row = mysql_fetch_array($result))
  {
  echo '<p>'.'<span>'.$row['sender'].'</span>'. '&nbsp;&nbsp;' . $row['message'].'</p>';
   if ($row['message']=='Courses'|| 'courses'){

			
				$message=' <br> Bsc. Computer Science<br> B.A. Communication and Media';
						$sender='Shark';
						
		mysql_query("INSERT INTO message(message, sender)VALUES('$message', '$sender')");

				echo '<br>';
		

	  
	  }
	     if ($row['message']=='Hey'|| 'Hi' || 'Hello'){

			
				$message=' How are you? My name is shark what can i do for you?';
						$sender='Shark';
						
		mysql_query("INSERT INTO message(message, sender)VALUES('$message', '$sender')");

				echo '<br>';
		

	  
	  }
  }
  				mysql_query("DELETE FROM message WHERE message ='Courses'");

mysql_close($con);
?>
