<?php
include("validation.php");

include("conection.php");
include("head.php");
	$adminid = "";
	$password = "";
	$adminname = "";
	$category = "";
	$firstname = "";
	$lastname = "";
	$middlename = "";
	$job = "";
$contact = 	"";
if(isset($_POST["button"]))
{
		if(($_POST["category"])=="Applicant")
	{
	$pwde = md5($_POST["password"]);
$sql="INSERT INTO applicant (user, pass, category, Firstname, Lastname, Middlename, Job,contact)
VALUES
('$_POST[adminname]','$pwde','$_POST[category]','$_POST[firstname]','$_POST[lastname]','$_POST[middlename]','$_POST[job]','$_POST[contactno]')";

if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }
  	$pwde = md5($_POST["password"]);
$sql="INSERT INTO tblgroupinfo(GroupReg) VALUES
('$_POST[adminname]')";
if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }
  else
  {
	  echo "Applicant Registered Successfully...";
  }
	}
		if(($_POST["category"])=="Admin")
	{
	$pwde = md5($_POST["password"]);
$sql="INSERT INTO admin (user, pass, category, Firstname, Lastname, Middlename, Job,contact)
VALUES
('$_POST[adminname]','$pwde','$_POST[category]','$_POST[firstname]','$_POST[lastname]','$_POST[middlename]','$_POST[job]','$_POST[contactno]')";

if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }
  else
  {
	  echo "Admin Registered Successfully...";
  }
	}
}
$result = mysql_query("SELECT * FROM applicant");
while($row1 = mysql_fetch_array($result))
  {
	$adminid = $row1["id"]+1;
	}
if(isset($_POST["button2"]))
{
	if(($_POST["category"])=="Applicant")
	{
	$pwde = md5($_POST[password]);
mysql_query("UPDATE applicant SET 	user='$_POST[adminname]', 	category='$_POST[category]',Firstname='$_POST[firstname]' ,Lastname='$_POST[lastname]',Middlename='$_POST[middlename]',	Job='$_POST[job]',contact='$_POST[contactno]'
WHERE adminid = '$_POST[adminid]'");
echo "User details updated successfully";
	}
		if(($_POST["category"])=="Admin")
	{
	$pwde = md5($_POST[password]);
mysql_query("UPDATE admin SET 	user='$_POST[adminname]', 	category='$_POST[category]',Firstname='$_POST[firstname]' ,Lastname='$_POST[lastname]',Middlename='$_POST[middlename]',	Job='$_POST[job]',contact='$_POST[contactno]'
WHERE adminid = '$_POST[adminid]'");
echo "User details updated successfully";
	}
}


if($_GET["view"] == "administrator")
{
$result = mysql_query("SELECT * FROM admin where adminid='$_GET[slid]'");	
 while($row1 = mysql_fetch_array($result))
  {
	$adminid = $row1["adminid"];
	$password = $row1["password"];
	$adminname = $row1["adminname"];
	$category = $row1["category"];
	$firstname = $row1["firstname"];
	$lastname = $row1["lastname"];
	$middlename = $row1["middlename"];
	$job = $row1["job"];
$contact = 	$row1["contactno"];
	}
}



?> 
<img src='images/logo.png' width="224" height="159"   />
<form name="form1" method="post" action="" id="formID">
  <p>
    <label for="adminid">Applicant ID</label><br />
    <input type="text" name="adminid" id="adminid"  class="validate[required] text-input" value="<?php echo $adminid; ?>">
</p>
  <p>
    <label for="adminname">Group Registration Number</label><br />
    <input type="text" name="adminname" id="adminname"  class="validate[required] text-input"  value="<?php echo $adminname; ?>">
</p>
<p>
    <label for="category">Category </label><br />
    <input type="text" name="category" id="category"  class="validate[required,custom[onlyLetterSp]] text-input"  value="<?php echo $category; ?>">
</p>
<p>
    <label for="firstname">First Name</label><br />
    <input type="text" name="firstname" id="firstname"  class="validate[required,custom[onlyLetterSp]] text-input"  value="<?php echo $firstname; ?>">
</p>
<p>
    <label for="lastname">Last Name</label><br />
    <input type="text" name="lastname" id="lastname"  class="validate[required,custom[onlyLetterSp]] text-input"  value="<?php echo $lastname; ?>">
</p>
<p>
    <label for="firstname">Middle Name</label><br />
    <input type="text" name="middlename" id="middlename"  class="validate[required,custom[onlyLetterSp]] text-input"  value="<?php echo $middlename; ?>">
</p>
<p>
    <label for="job">Job</label><br />
    <input type="text" name="job" id="job"  class="validate[required,custom[onlyLetterSp]] text-input"  value="<?php echo $job; ?>">
</p>
<p>
  <label for="password">Password</label><br />
  <input type="password" name="password" id="password"  class="validate[required] text-input" >
</p>
 <p>
    <label for="cpassword">Confirm Password</label><br />
    <input type="password" name="cpassword" id="cpassword" class="validate[required,equals[password]] text-input">
</p>

  <p>
    <label for="contactno">Contact No</label><br />
    <input type="text" name="contactno" id="contactno"  class="validate[required,custom[phone]] text-input" value="<?php echo $contact; ?>">
</p>
  <p>
    <input type="submit" name="button" id="button" value="Submit">
<form id="myform">
  <input type="button" value="Close" name="B1" onClick="parent.emailwindow.hide()" /></p>
</form>
  </p>
</form>
<a href='index.php'><< I have an Account! Sign In.</a>
