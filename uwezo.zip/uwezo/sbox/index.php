<?php
	putenv("TZ=US/Eastern");
	session_start();
	//$link = mysql_connect("mysql.domain.com","username","password") or die("DBE1");
	//mysql_select_db('databasename') or die("DBE2");
	include('sb_core.php');
	//mysql_close($link);
?>