<?php 
	/*
		SB 2.2 beta: MVC Recursive Routing Framework
		Tuesday, April 20, 2008
		Daniel Slaughter
		danielslaughter.com
	*/
		//phpinfo();
	
	$sb = array();
	$sb['redirect'] = '';
	
	// get the url being requested
	if (isSet($_SERVER['SCRIPT_URL']) && false) {
		$url = trim(substr($_SERVER['SCRIPT_URL'], strlen(substr($_SERVER["SCRIPT_NAME"],0,strlen($_SERVER["SCRIPT_NAME"])-9))),'/');
	} else if (isSet($_SERVER['REQUEST_URI'])) {
		$url = explode('?',$_SERVER['REQUEST_URI']);
		$url = trim(substr($url[0], strlen(substr($_SERVER["SCRIPT_NAME"],0,strlen($_SERVER["SCRIPT_NAME"])-9))),'/');
	} else {
		die('An internal Switchboard error has occured. Switchboard could not determine the url being requested.');
	}
	// take the url requested and convert it to an array for recursive routing
	if (strlen($url) == 0)
		$url = 'index';
	else
		$url = substr($url,0,strlen($url)-4);
	$sb['routing'] = explode('-', $url);
	$sb['circuitCount'] = count($sb['routing'])-1;
	
	// INCLUDE THE ROOT'S SETTINGS FILE
	if ( file_exists("sb_settings.php") )
		include "sb_settings.php";
	else
		die('An internal Switchboard error has occured. Switchboard could not locate the sb_settings.php file in the root of the directory.');

	// SET UP THE CIRCUIT
	if ($sb['circuitCount'] == 0) {
		$sb['circuit'] = '/';
		$sb['page'] = $sb['routing'][0];
	} else {
		$sb['circuit'] = '';
		for ($i = 0; $i < $sb['circuitCount']; $i++) {
			$sb['circuit'] .= $sb['routing'][$i] . '/';
			// INCLUDE CIRCUIT'S SETTINGS
			if (file_exists($sb['circuit'] . "sb_settings.php"))
				include $sb['circuit'] . "sb_settings.php";
		}
		$sb['page'] = $sb['routing'][$sb['circuitCount']];
	}

	// AUTHENTICATE
	if ($sb['useAuthentication']) {
		if (!$sb['hasAuthentication'] && !in_array($url.'.htm', $sb['noAuthentication'])) {
			header("Location: " . $sb['noAuthenticationRedirect']);
			die('Authentication Failed, redirecting');
		}
		else if ($sb['hasAuthentication'] && in_array($url.'.htm', $sb['noAuthentication'])) {
			header("Location: " . $sb['authenticationRedirect']);
		}
	}
	
	// INCLUDE ROOT/CIRCUIT SWITCH
	if ($sb['circuitCount'] == 0) {
		if (file_exists("sb_switch.php"))
			include "sb_switch.php";
	} else {
		if (file_exists($sb['circuit'] . "sb_switch.php"))
			include $sb['circuit'] . "sb_switch.php";
	}
	
	// GENERATE PAGE CONTENT
	$sb['contentGenerated'] = false;
	ob_start();
		if ( $sb['useController'] && file_exists(trim($sb['circuit'] . "controller", '/') . '/' . $sb['page'] . ".php") ) {
			include trim($sb['circuit'] . "controller", '/') . '/' . $sb['page'] . ".php";
			$sb['contentGenerated'] = true;
		}
		if ( $sb['useModel'] && file_exists(trim($sb['circuit'] . "model", '/') . '/' . $sb['page'] . ".php") ) {
			include trim($sb['circuit'] . "model", '/') . '/' . $sb['page'] . ".php";
			$sb['contentGenerated'] = true;
		}
		if ( $sb['useView'] && file_exists(trim($sb['circuit'] . "view", '/') . '/' . $sb['page'] . ".php") ) {
			include trim($sb['circuit'] . "view", '/') . '/' . $sb['page'] . ".php";
			$sb['contentGenerated'] = true;
		}
		// NO MVC PAGES FOUND, THROW AN ERROR
		if (!$sb['contentGenerated']) {
			if (file_exists("controller/" . $sb['errorPage'] . ".php"))
				include "controller/" . $sb['errorPage'] . ".php";
			if (file_exists("model/" . $sb['errorPage'] . ".php"))
				include "model/" . $sb['errorPage'] . ".php";
			if (file_exists("view/" . $sb['errorPage'] . ".php"))
				include "view/" . $sb['errorPage'] . ".php";
		}		
	$sb['content'] = ob_get_clean();
	
	// CHECK FOR REDIRECT, AND DISPLAY
	if ( $sb['redirect'] == '' ) {
		if ( $sb['useTemplate'] ) {
			if ($sb['circuitCount'] > 0) {
				// INCLUDE CIRCUIT'S TEMPLATES
				for ($i = $sb['circuitCount']; $i > 0; $i--) {
					$sb['circuit'] = '';
					for ($j = 0; $j < $i; $j++) {
						$sb['circuit'] .= $sb['routing'][$j] . '/';
					}
					ob_start();
						if (file_exists($sb['circuit'] . "sb_template.php")) {
							include $sb['circuit'] . "sb_template.php";
						} else {
							echo $sb['content'];
						}
					$sb['content'] = ob_get_clean();
				}
				
			}
			if (file_exists("sb_template.php"))
				include "sb_template.php";
			else
				die('An internal Switchboard error has occured. Switchboard could not locate the sb_template.php file in the root of the directory.');
		} else {
			echo $sb['content'];
		}
	// REDIRECT
	} else {
		header("Location: " . $sb['redirect']);
		die('<a href="' . $sb['redirect'] . '">Redirecting</a>');
	}
?>