<?php
include("head.php");
include("conection.php");

if(isset($_POST["button"]))
{
header ("location: index.html");
}


if($_GET["view"] == "err")
{
	
	$sql="UPDATE applicant SET closed='true' WHERE category='applicant'";
if (!mysql_query($sql,$con))
  {
  
  die('Error: ' . mysql_error());
  }
  else
  {
	  echo "Uwezo Loan Closed";
  }
	
}

if($_GET["view"] == "opp")
{
	
	$sql="UPDATE applicant SET closed='' WHERE category='applicant'";
if (!mysql_query($sql,$con))
  {
  
  die('Error: ' . mysql_error());
  }
  else
  {
	  echo "Uwezo Loans Opened";
  }
	
}
?>
<section id="page">
<header id="pageheader" class="normalheader">
<h2 class="sitedescription">
 </h2>
</header>

<section id="contents">

<article class="post">
  <header class="postheader"><img src='images/logo.png' width="224" height="159"   />
  <h2> Loan Applications Currently Closed</h2>

  </header>
  <section class="entry">


<h4>Uwezo Fund Loan Application Process is currently closed. </h4>
                            <h4>If you have any loan issues feel free to <a href="contact.php">Contact The Uwezo Team</a> </h4>
  </section>
</article>


</section>

<p>&nbsp;</p>
<form name="form1" method="post" action="">
  <input type="submit" name="button" id="button" value="Back to Site">
</form>
