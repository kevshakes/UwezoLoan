<?php
session_start();
include("conection.php");
include("validation.php");
if (!isset ($_SESSION['admin']))
{
//header ("location: index.php");;
}
$ownID =  "";
$ownname = "";
$name = "";
$reg = "";
$biznat = "";
$bizsect= "";
$biztype= "";
$owncell=  "";
$nxtkin= "";
$kinrelshp= "";
$kincell= "";
$guaname="";
$guaID= "";
$guacell= "";
$loanappl= "";
$loanrepay= "";
$comment= "";
$ownid= "";

if($_GET["view"] == "delete")
{
mysql_query("DELETE FROM tblgroupmembloan WHERE OwnerID ='$_GET[memb]'");
}
$result = mysql_query("SELECT * FROM tblgroupmembloan");

 if(isset($_POST["addnew"]))
  {

$sql1="INSERT INTO tblgroupmembloan (GroupReg,OwnerID) VALUES
('$_POST[grp_reg]','$_POST[own_id]')";
$reg = $_POST['grp_reg'];
$newID=$_POST['own_id'];
if (!mysql_query($sql1,$con))
  {
  die('Error: ' . mysql_error());
  }
    header("Location: applicant3.php?view=applicantdetails&slid=$reg&memb=$newID");
}



  if(isset($_POST["addother"]))
  {
	  if($_POST['loan_repay']>24)
	 {
		 die('User Critical Error: Loan Repayment Period must be less than 24 months');
		 
	 }
	 if($_POST['loan_appl']>500000)
	 {
		 		 die('User Critical Error: Loan Applied must be less than Ksh. 500,000');
	 }
	 
	 
$oldid = $_POST['own_id'];
$sql="UPDATE tblgroupmembloan SET OwnerID='$_POST[own_id]',OwnerName='$_POST[own_name]',BizNature='$_POST[biz_nat]',BizSector='$_POST[biz_sect]',IndivBizType='$_POST[indivbiz_type]',OwnerMobile='$_POST[own_mobile]',NextOfKin='$_POST[nextof_kin]',	KinRelshipType='$_POST[kin_relshiptype]',KinMobile='$_POST[kin_mobile]',GuarantorName='$_POST[guar_name]',LoanApplied='$_POST[loan_appl]',LoanRepaymentPeriod='$_POST[loan_repay]' ,GuarantorID='$_POST[guar_id]',GuarantorMobile='$_POST[guar_mobile]',Comments='$_POST[comments]'WHERE OwnerID='$oldid'";
$reg = $_POST['grp_reg'];
$owns = $_POST['own_id'];
if (!mysql_query($sql,$con))
  {
  die('Error in mysql: ' . mysql_error());
  }
  else
  {
echo "Member added successfully";
  header("Location: applicant3.php?view=applicantdetails&slid=$reg&memb=$owns");
  }

}
	if($_GET["view"] == "applicantdetails")
{
$result = mysql_query("SELECT * FROM tblgroupinfo where GroupReg='$_GET[slid]'");	
  while($row = mysql_fetch_array($result))
  {
$name =  $row["GroupName"];
$reg = $row["GroupReg"];
	
	}
$result2 = mysql_query("SELECT * FROM tblgroupmembloan where OwnerID='$_GET[memb]'");	
  while($row2 = mysql_fetch_array($result2))
  {
$ownID =  $row2["OwnerID"];
$ownname = $row2["OwnerName"];
$biznat = $row2["BizNature"];
$bizsect= $row2["BizSector"]; 
$biztype= $row2["IndivBizType"];
$owncell=  $row2["OwnerMobile"];
$nxtkin= $row2["NextOfKin"];
$kinrelshp= $row2["KinRelshipType"];
$kincell= $row2["KinMobile"];
$guaname= $row2["GuarantorName"];
$guaID= $row2["GuarantorID"];
$guacell= $row2["GuarantorMobile"];
$loanappl= $row2["LoanApplied"];
$loanrepay= $row2["LoanRepaymentPeriod"];
$comment= $row2["Comments"];
	
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title>Uwezo Fund - Online Loan Application</title>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
		<!-- Begin JavaScript -->

		<script type="text/javascript" src="lib/jquery-1.3.2.min.js"></script>
		<script type="text/javascript" src="lib/jquery.tools.js"></script>
    	<script type="text/javascript" src="lib/jquery.custom.js"></script>
		<script type="text/javascript" src="lib/validate.js"></script>
<link href="images/icon.png"rel="shortcut icon" type="image" />
        <link href="styles.css" rel="stylesheet" type="text/css" media="screen" />
        <style type="text/css">
<!--
.style1 {color: #CCCCCC}
.style6 {color: #000000}
.style10 {font-weight: bold}
.style11 {font-size: large}
.style12 {color: #F0F0F0}
#Layer8 {	position:absolute;
	width:300px;
	height:115px;
	z-index:3;
	left: 16px;
	top: 12px;
}
.style13 {font-size: 14px}
-->
        </style>
</head>
    <body>
    <div id="content_bg">
       	  <div id="wraps">
        		<div id="top_wrap">
        			<div id="logo">
        				<h1><span class="style10"><a href="index.html">Welcome to Uwezo Fund Loan Application Portal </a></span></h1>
                    	<div id="Layer8"><img src="images/contacts.png" width="350" height="144" style="border:inset;border-color:#0099FF"/></div>
               	  <strong><a href="help.php"><small>Click here for for Loan Help.</small></a></strong> </div>
					<div class="header"><div>
							<ul><li class="button_box style11"></li>
							  <li class="button_box style11">
							    <div align="center" id="menu"class="style12"><span class="style13"><a href="applicant2.php?view=applicantdetails&slid=<?php echo $reg; ?>" >Information</a>
                                <a href="applicant2.php?view=applicantdetails&slid=<?php echo $reg; ?>" > Location </a>
                                <a href="approvalnotice.php?view=0&slid=<?php echo $reg; ?>"> Loan Approvals</a>
                                <a href="<?php 
// reset session array
$_SESSION = array();
// destroy session
session_destroy();?>" class="active"> Log Out </a></span></div>
						      </li>
							</ul>
						</div>
				  </div>
        		</div>
				<div id="content">
					<div id="content_top"></div>
					<div id="content_bg">
						<div class="content_left">
							<div class="blog_news">
								<h6>Uwezo Fund Loan Application - Group Membership And Loan Details</h6>
							    <div class="news_bar">
							    <div class="clear">
							      <p></p>
                                  							      <form name="form2" method="post" action="">
<table width="485" border="1">
  <tr>
When adding a new group member, just enter the ID number then click Add Group Member
  <tr>
    <td width="56">&nbsp;</td>
<td width="202"><strong>Name</strong></td>
    <td width="205"><strong>ID Number</strong></td>
  </tr>
  <?php
	  $i =1;
	  $result3 = mysql_query("SELECT * FROM tblgroupmembloan WHERE GroupReg=$_GET[slid]");
  while($row = mysql_fetch_array($result3))
  {
  echo "<tr>";
  echo "<td>&nbsp";
  ?>
  <a href="applicant3.php?view=delete&slid=<?php echo $_GET["slid"]; ?>&memb=<?php echo $row["OwnerID"]; ?>"><img src='images/delete.png' width='32' height='32'  onclick="return confirm('Delete Group member  with ID <?php echo $row["OwnerID"]; ?>?')"/></a>
  <?php
  echo  $i . " </td>";
     	  echo "<td>&nbsp;" . $row['OwnerName'] . "</td>";
	   echo "<td>&nbsp;<a href='applicant3.php?view=applicantdetails&slid=$_GET[slid]&memb=$row[OwnerID]'>" . $row['OwnerID'] . "</a></td>";
  echo "</tr>&nbsp;";
  $i++;
  }
  
?>
  <tr>
  </tr>
  <tr>
    <td height="25">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>

  </tr>
</table>
    </form>
							      <p class="style1 style6"> <span id="feedback" class="style6"><strong>Owner/Member National ID:</strong></span> </p>
							      <form id="frmgrpinfo" method="post" action="applicant3.php">
                                    <fieldset>
                                    <p>
																	
                                      <input id="grp_name" type="text" name="own_id" value="<?php echo $ownID; ?>"  alt=""/>
                                    </p>
                                         <p><span class="style6"><strong>Group Name</strong></span><br />
                                      <input id="grp_reg" type="text" name="grp_name" value="<?php echo $name; ?>" alt=""/>
                                    </p>
                                         <p><span class="style6"><strong>Group Registration Number</strong></span><br />
                                      <input id="grp_reg" type="text" name="grp_reg" value="<?php echo $reg; ?>" alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Name of Owner/Member:</strong></span><br />
                                      <input id="grp_reg" type="text" name="own_name" value="<?php echo $ownname; ?>" alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Nature of Business (to be) Undertaken e.g. Retail Grocery:</strong></span><br />
                                      <input id="grp_reg" type="text" name="biz_nat" value="<?php echo $biznat; ?>" alt=""/>
                                    <p><span class="style6"><strong>Business Sector e.g. Entrpreneurial/Commercial:</strong></span></p>
                                    <p>
									   <input id="grp_reg" type="text" name="biz_sect" value="<?php echo $bizsect; ?>" alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Type of Business (to be) Undertaken Start-up/Expansion</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="indivbiz_type" value="<?php echo $biztype; ?>" alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Mobile Number of Owner/Member:</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="own_mobile" value="<?php echo $owncell; ?>" alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Next of Kin:</strong></span></p></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="nextof_kin"alt="" value="<?php echo $nxtkin; ?>"/>
                                    </p>
                                    <p><span class="style6"><strong>Type of Relationship with Next of Kin:</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="kin_relshiptype" value="<?php echo $kinrelshp; ?>" alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Mobile Number of Next of Kin:</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="kin_mobile"  value="<?php echo $kincell; ?>"alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Name of Guarantor:</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="guar_name" value="<?php echo $guaname; ?>"  alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>National ID of Guarantor:</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="guar_id" value="<?php echo $guaID; ?>" alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Mobile Number of Guarantor:</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="guar_mobile" value="<?php echo $guacell; ?>"  alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Loan Amount Applied for(Group Loan in Kshs):</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="loan_appl" value="<?php echo $loanappl; ?>"  alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Loan Repayment Period(In Months, Max 24):</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="loan_repay" value="<?php echo $loanrepay; ?>" class="validate[required,custom[url]] text-input" alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Any Additional Final Information/Comments</strong></span><br />
                                        <input id="con_address" name="comments" class="validate[required] text-input" cols="0" rows="0" value="<?php echo $comment; ?>" />
                                      <br />
                                                                              <input name="addother" type="submit" id="contact-submit" value="Update Group Member"/>
                                                                                         <input name="addnew" type="submit" id="contact-submit" value="Add Group Member"/>
                                       
                                        
                                    </p>
                                    </p>
                                    </fieldset>
						          </form>

							    </div>
							  </div>
						  </div>
							<div class="blog_news">
							  <div class="clear"></div>
							</div>			
						</div>
						<div class="clear"></div>
					</div>
					<div id="content_bot"></div>
				</div>
				<div id="footer">
					<div id="footer_column">
						<div id="footer_con_bg">
							<div id="footer_con_top">
								<div id="footer_con_bot">
								
              
							<div class="clear"></div>
							<div class="button_box">
								<blockquote>
								  <blockquote>
                                    <p><a href="http://www.facebook.com"><img src="images/facebook.png" alt="" title=""/></a> 
									<a href="http://www.twitter.com"><img src="images/twitter.png" alt="" title=""/></a> 
									<a href="http://www.yahoo.com"><img src="images/yahoo.png" alt="" title=""/></a> 
									<a href="http://www.rss.com"><img src="images/rss.png" alt="" title=""/></a> 
									<a href="http://www.youtube.com"><img src="images/youtube.png" alt="" title=""/></a></p>
							            </p>
							      </blockquote>
							  </blockquote>
                        </div>
                        <div style="clear: both"></div>								
								</div>
							</div>
						</div>
					</div>
					<div id="footer_bot">
						<p>Copyright  2014. </p>
                        <!-- Please DO NOT remove the following notice --><p>Design by <a href="http://facebook.com/ktuei" title="COMP402 Computer Systems Project">Kevin Tuei, EBS1/02955/10</a></p><!-- end of copyright notice-->
					</div>
				</div>	
        	</div>
        </div>
    </body>
</html>
