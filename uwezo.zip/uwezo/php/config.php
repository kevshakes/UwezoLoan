<?php
$host="localhost";
$username="root";
$serverpassword="";
$db="uwezo";
$con=mysql_connect($host,$username,$serverpassword);
mysql_connect($host,$username,$serverpassword) or die(mysql_error());
mysql_select_db($db) or die(mysql_error());
?>