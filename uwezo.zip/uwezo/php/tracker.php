<?php
include("config.php");
$username='admin';
$query="SELECT * FROM admin where user ='$username'";
$res=mysql_query($query);
$row=mysql_fetch_array($res);
?>
