<?php
session_start();
if(isset($_SESSION["userid"]))
{
		if($_SESSION["type"]=="applicant")
	{

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title>Uwezo Fund - Online Loan Application</title>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
		<!-- Begin JavaScript -->

		<script type="text/javascript" src="lib/jquery-1.3.2.min.js"></script>
		<script type="text/javascript" src="lib/jquery.tools.js"></script>
    	<script type="text/javascript" src="lib/jquery.custom.js"></script>
		<script type="text/javascript" src="lib/validate.js"></script>
<link href="images/icon.png"rel="shortcut icon" type="image" />
        <link href="styles.css" rel="stylesheet" type="text/css" media="screen" />
        <style type="text/css">
<!--
.style1 {color: #CCCCCC}
.style6 {color: #000000}
.style10 {font-weight: bold}
.style11 {font-size: large}
.style12 {color: #F0F0F0}
#Layer8 {	position:absolute;
	width:300px;
	height:115px;
	z-index:3;
	left: 16px;
	top: 12px;
}
.style13 {font-size: 14px}
-->
        </style>
</head>
<?php
include("conection.php");
include("validation.php");
$const =  "";
$county = "";
$ward = "";
$loc= "";
$subloc= "";
$chiefname=  "";
$chiefcell= "";
$certify= "";
$bizar= "";
$bizarname= "";
$biznlmtype= "";
$biznlmname= "";
$bizstrtplotno= "";
$biztype= "";
$jointbiz= "";
$regno= "";
if (!isset ($_SESSION['admin']))
{
//header ("location: index.php");;
}

$result1 = mysql_query("SELECT * FROM tblgroupmembloan  where GroupReg='$_GET[slid]'");
$chk = $_GET['slid'];
  while($roww = mysql_fetch_array($result1))
  {
$regno = $roww["GroupReg"];

	}
if($regno!=$chk)
{
$sql1="INSERT INTO tblgroupmembloan (GroupReg) VALUES
('$_GET[slid]')";
if (!mysql_query($sql1,$con))
  {
  die('Error: ' . mysql_error());
  }
}

$result = mysql_query("SELECT * FROM tblgroupinfo");
$result1 = mysql_query("SELECT * FROM tblgroupmembloan  where GroupReg='$_GET[slid]'");

if(isset($_POST["button2"]))
{	
if(!$result1)
{
		$sql="INSERT INTO tblgroupmembloan(GroupReg) VALUES
('$_GET[slid]')";
if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }
}
$sql="UPDATE tblgroupbizloc SET GroupConstituency='$_POST[grp_constituency]',GroupCounty='$_POST[grp_county]',GroupWard='$_POST[grp_ward]',GroupLocation='$_POST[grp_location]',GroupSubLocation='$_POST[grp_sublocation]',GroupChiefAsstName='$_POST[grp_chiefasstname]',	GroupChiefAsstMobile='$_POST[grp_chiefasstmobile]',BizArea='$_POST[grp_bizarea]',BizAreaName='$_POST[grp_areaname]',BizNearstLandmarkType='$_POST[grp_nearestLandmarkType]',BizNearstLandmarkName='$_POST[grp_nearestLandmarkName]' ,BizStreetPlotNo='$_POST[grp_streetplotNo]',BizType='$_POST[grp_biztype]',JointBiz='$_POST[grp_jointbiz]'WHERE GroupReg='$_POST[grp_reg]'";
$reg = $_POST['grp_reg'];
if (!mysql_query($sql,$con))
  {
  
  die('Error: ' . mysql_error());
  }
  else
  {
	  echo "Group Location updated Successfully...";
  }
header("Location: applicant2.php?view=applicantdetails&slid=$reg");
}




if($_GET["view"] == "applicantdetails")
{
$result = mysql_query("SELECT * FROM tblgroupinfo where GroupReg='$_GET[slid]'");	
  while($row = mysql_fetch_array($result))
  {
$name =  $row["GroupName"];
$reg = $row["GroupReg"];
	
	}

$result2 = mysql_query("SELECT * FROM tblgroupbizloc where GroupReg='$_GET[slid]'");	
  while($row2 = mysql_fetch_array($result2))
  {
	$reg =  $row2["GroupReg"];
$const =  $row2["GroupConstituency"];
$county = $row2["GroupCounty"];
$ward = $row2["GroupWard"];
$loc= $row2["GroupLocation"]; 
$subloc= $row2["GroupSubLocation"];
$chiefname=  $row2["GroupChiefAsstName"];
$chiefcell= $row2["GroupChiefAsstMobile"];
$certify= $row2["GroupCertify"];
$bizar= $row2["BizArea"];
$bizarname= $row2["BizAreaName"];
$biznlmtype= $row2["BizNearstLandmarkType"];
$biznlmname= $row2["BizNearstLandmarkName"];
$bizstrtplotno= $row2["BizStreetPlotNo"];
$biztype= $row2["BizType"];
$jointbiz= $row2["JointBiz"];
	
	}
}
?>


    <body>
        <div id="bg_bubble">
        	<div id="wrap">
        		<div id="top_wrap">
        			<div id="logo">
        				<h1><span class="style10"><a href="index.html">Welcome to Uwezo Fund Loan Application Portal </a></span></h1>
                    	<div id="Layer8"><img src="images/contacts.png" width="350" height="144" style="border:inset;border-color:#0099FF"/></div>
                    	<strong><a href="help.php"><small>Click here for for Loan Help. </small></a></strong>
                   	  <h1>&nbsp; </h1>
       			  </div>
					<div class="header"><div>
							<ul><li class="button_box style11"></li>
							  <li class="button_box style11">
							    <div id="content_bg" align="left" class="style12"><span class="style13">
                                <a href="applicant1.php?view=applicantdetails&slid=<?php echo $reg; ?>" >Information</a>
                              
                                <a href="applicant3.php?view=applicantdetails&slid=<?php echo $reg; ?>&memb=0"> Membership and Loan</a>
                                <a href="approvalnotice.php?view=0&slid=<?php echo $reg; ?>"> Loan Approvals</a><a href="<?php
// reset session array
$_SESSION = array();
// destroy session
session_destroy();
 ?>" class="active"> Log Out </a></span></div>
						      </li>
							</ul>
						</div>
				  </div>
        		</div>
				<div id="content">
					<div id="content_top"></div>
					<div id="content_bg">
						<div class="content_left">
							<div class="blog_news">
								<h6>Uwezo Fund Loan Application - Youth/Women Group and Business Location</h6>
							    <div class="news_bar">
							    <div class="clear">
							      <p>&nbsp;</p>
							      <p class="style1 style6"> <span id="feedback" class="style6"><strong>Group Registration Number</strong></span> </p>
							      <form id="frmgrploc" method="post" action="applicant2.php">
                                    <fieldset>
                                    <p>
																	
                                      <input id="grp_name" type="text" name="grp_reg"  alt="" value="<?php echo $reg; ?>"/>
                                    </p>
                                                                        <p><span class="style6"><strong>Group Name</strong></span><br />
                                      <input id="grp_reg" type="text" name="grp_name" value="<?php echo $name; ?>" alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Group Constituency</strong></span><br />
                                      <input id="grp_reg" type="text" name="grp_constituency" value="<?php echo $const; ?>"  alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Group County</strong></span><br />
                                      <input id="grp_reg" type="text" name="grp_county" value="<?php echo $county; ?>"  alt=""/>
                                    </p>
                                    
                                    <p><span class="style6"><strong>Group Ward</strong></span><br />
                                      <input id="grp_reg" type="text" name="grp_ward" value="<?php echo $ward; ?>" alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Group Location(Area Under a Chief)</strong></span><br />
                                      <input id="grp_reg" type="text" name="grp_location" value="<?php echo $loc; ?>" alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Group Sub-Location:</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_sublocation" value="<?php echo $subloc; ?>"  alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Chief/Assistant-Chief's Name</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_chiefasstname" value="<?php echo $chiefname; ?>" alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Chief/Assistant-Chief's Mobile Number</strong></span></p></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_chiefasstmobile" value="<?php echo $chiefcell; ?>"alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Business Area(Township/Estate/Village) of the Group</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_bizarea" value="<?php echo $bizar; ?>"  alt=""/>
                                      </p>
                                    <p><span class="style6"><strong>Name of the Business Area</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_areaname" value="<?php echo $bizarname; ?>"  alt=""/>
                                      </p>
                                    <p><span class="style6"><strong>Type of Landmark Nearest to the Business(Church/Mosque/Primary School)</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_nearestLandmarkType" value="<?php echo $biznlmtype; ?>"  alt=""/>
                                      </p>
                                    <p><span class="style6"><strong>Name of Landmark Nearest to the Business</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_nearestLandmarkName" value="<?php echo $biznlmname; ?>" alt=""/>
                                      </p>
                                    <p><span class="style6"><strong>Business Street/Plot Number</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_streetplotNo" value="<?php echo $bizstrtplotno; ?>"  alt=""/>
                                      </p>
                                    <p><span class="style6"><strong>What is the type of business?</strong></span></p>
                                    <p>

    <input type="radio" name="grp_biztype" id="radio" value="Start-up" <?php
  if($biztype == "Start-up")
  {
	  echo "checked";
  }
  ?> class="validate[required] radio" >
    <label for="radio" class="style6">Start-up</label>
    <input type="radio" name="grp_biztype" id="radio2" value="Expansion"  <?php if($biztype == "Expansion")
  {
	  echo "checked";
  }?> class="validate[required] radio" >
    <label for="radio2" class="style6">Expansion</label>
  </p>
  <p>
                                      </p>
                                    <p><span class="style6"><strong>Is the Business a joint business?</strong></span></p>
                                    <p>
    <input type="radio" name="grp_jointbiz" id="radio" value="No" <?php
  if($jointbiz == "No")
  {
	  echo "checked";
  }
  ?> class="validate[required] radio" >
    <label for="radio" class="style6">No</label>
    <input type="radio" name="grp_jointbiz" id="radio2" value="Yes"  <?php if($jointbiz == "Yes")
  {
	  echo "checked";
  }?> class="validate[required] radio" >
    <label for="radio2" class="style6">Yes</label>
  </p>
  <p>
                                      </p>
                                    <br />
<input name="button2" type="submit" id="contact-submit" value="Update Group and Business Location"/>

                                                                                               
                                    </p>
                                    </p>
                                    </fieldset>
						          </form>

							    </div>
							  </div>
						  </div>
							<div class="blog_news">
							  <div class="clear"></div>
							</div>			
						</div>
						<div class="clear"></div>
					</div>
					<div id="content_bot"></div>
				</div>
				<div id="footer">
					<div id="footer_column">
						<div id="footer_con_bg">
							<div id="footer_con_top">
								<div id="footer_con_bot">
								
              
							<div class="clear"></div>
							<div class="button_box">
								<blockquote>
								  <blockquote>
                                    <p><a href="http://www.facebook.com"><img src="images/facebook.png" alt="" title=""/></a> 
									<a href="http://www.twitter.com"><img src="images/twitter.png" alt="" title=""/></a> 
									<a href="http://www.yahoo.com"><img src="images/yahoo.png" alt="" title=""/></a> 
									<a href="http://www.rss.com"><img src="images/rss.png" alt="" title=""/></a> 
									<a href="http://www.youtube.com"><img src="images/youtube.png" alt="" title=""/></a></p>
							            </p>
							      </blockquote>
							  </blockquote>
                        </div>
                        <div style="clear: both"></div>								
								</div>
							</div>
						</div>
					</div>
					<div id="footer_bot">
						<p>Copyright  2014. </p>
                        <!-- Please DO NOT remove the following notice --><p>Design by <a href="http://facebook.com/ktuei" title="COMP402 Computer Systems Project">Kevin Tuei, EBS1/02955/10</a></p><!-- end of copyright notice-->
					</div>
				</div>	
        	</div>
        </div>
    </body>
</html>
<?php 
}
}
else
{
		header("Location: index.php");
}


?>