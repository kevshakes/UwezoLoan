<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>

        <title>Uwezo Fund - Kenya Government</title>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
		<!-- Begin JavaScript -->

		<script type="text/javascript" src="lib/jquery-1.3.2.min.js"></script>
		<script type="text/javascript" src="lib/jquery.tools.js"></script>
    	<script type="text/javascript" src="lib/jquery.custom.js"></script>
        <link href="images/icon.png"rel="shortcut icon" type="image" />

        <link href="styles.css" rel="stylesheet" type="text/css" media="screen" />
        <style type="text/css">
<!--
.style1 {color: #000000}
-->
        </style>
</head>
    <body>
        <div id="bg_bubble">
        	<div id="wrap">
        		<div id="top_wrap">
        			<div id="logo">
        				<h1><a href="index.html">Uwezo fund - Kenya Government </a></h1>
               	  <a href="#"><small>Ahadi Yetu - Kazi Kwako </small></a></div>
					<div class="header"><div id="menu">
							<ul>
			                	<li><a href="index.html" >Home</a></li>
								<li><a href="aboutus.html">About Us</a></li>
			                    <li><a href="faqs.html">FAQs</a></li>
			                    <li><a href="gallery.html">Photo Gallery</a></li>	
			                    <li><a href="contact.php" class="active">Contact Us</a></li>
			                </ul>
						</div>
						<div id="header_img">
							<div id="slider_bg">
								<div class="waveshow">

									<img src="images/s4.jpg" alt="" width="660" height="338" title="Uwezo Fund Contacts" />
							</div> 
								<!-- waveshow -->
							</div> <!-- slider_bg -->
						</div>
					</div>
        		</div>
                <br />
                <p>