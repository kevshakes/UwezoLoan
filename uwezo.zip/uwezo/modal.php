<!-- /*************************************************/ -->
<link rel="stylesheet" href="modal/windowfiles/dhtmlwindow.css" type="text/css" />
<script type="text/javascript" src="modal/windowfiles/dhtmlwindow.js">
</script>
<link rel="stylesheet" href="modal/modalfiles/modal.css" type="text/css" />
<script type="text/javascript" src="modal/modalfiles/modal.js"></script>
<!-- /*************************************************/ -->

<!-- /*************************************************/ -->
<script type="text/javascript">



function openregister(){
	emailwindow=dhtmlmodal.open('EmailBox', 'iframe', 'register.php?view=0&slid=0', 'Register New Applicant', 'width=550px,height=520px,center=1,resize=0,scrolling=1')

} 

function openadmin(){
	emailwindow=dhtmlmodal.open('EmailBox', 'iframe', 'addadmin.php', 'Insert admin detail', 'width=550px,height=520px,center=1,resize=0,scrolling=1')

} 

function openattendance(){
	emailwindow=dhtmlmodal.open('EmailBox', 'iframe', 'attendance.php', 'Insert Attendance detail', 'width=1000px,height=750px,center=1,resize=0,scrolling=1')

} 


  </script>

<!-- /*************************************************/ -->