<?php
session_start();
session_start();
if(isset($_SESSION["userid"]))
{
		if($_SESSION["type"]=="applicant" || $_SESSION["type"]=="admin")
	{
include("head.php");
include("conection.php");

if(isset($_POST["button"]))
{
header ("location: index.html");
}
// reset session array
	$_SESSION['userid'] = "";
	$_SESSION['type'] = "";
	$_SESSION["adminname"] = "";
// destroy session
session_destroy();
?>
<section id="page">
<header id="pageheader" class="normalheader">
<h2 class="sitedescription">
 </h2>
</header>

<section id="contents">

<article class="post">
  <header class="postheader"><img src='images/logo.png' width="224" height="159"   />
  <h2> Logged out Successfully</h2>

  </header>
  <section class="entry">


<h4>Uwezo Fund Loan Application Process session closed. </h4>
                            
  </section>
</article>


</section>

<p>&nbsp;</p>
<form name="form1" method="post" action="">
  <input type="submit" name="button" id="button" value="Back to Site">
</form>
<?php 
}
}
else
{
		header("Location: index.html");
}


?>