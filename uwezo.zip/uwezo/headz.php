<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>

        <title>Uwezo Fund - Kenya Government</title>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
		<!-- Begin JavaScript -->

		<script type="text/javascript" src="lib/jquery-1.3.2.min.js"></script>
		<script type="text/javascript" src="lib/jquery.tools.js"></script>
    	<script type="text/javascript" src="lib/jquery.custom.js"></script>
        <link href="images/icon.png"rel="shortcut icon" type="image" />

        <link href="styles.css" rel="stylesheet" type="text/css" media="screen" />
        <style type="text/css">
<!--
.style1 {color: #000000}
-->
        </style>
</head>
    <body bgcolor="#9900CC">
        <div id="bg_bubble">
        	<div id="wrap">
        			<div id="logo">
        				<h1><a href="index.html">Uwezo fund - Kenya Government </a></h1>
               	  <a href="#"><small>Ahadi Yetu - Kazi Kwako </small></a></div>
				  <div class="header"></div>
        		</div>
                <br />
                <p>
                <?php include("validation.php");?>