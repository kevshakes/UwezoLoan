<?php
if(isset($_SESSION["userid"]))
{
	if($_SESSION["type"]=="admin")
	{
	header("Location: applicant1.php");
	}
	else
	{	
	header("Location: index.php");
	}
}

if(isset($_POST["username"]) && isset($_POST["pass"]) )
{
//	echo "sdfsd".	$_POST[uid];
$result = mysql_query("SELECT * FROM admin WHERE user='$_POST[username]'");
$result1 = mysql_query("SELECT * FROM tblgroupinfo WHERE GroupReg='$_POST[username]'");
while($row = mysql_fetch_array($result))
  {
$pwdmd5 = $row["pass"];
  }
 while($row = mysql_fetch_array($result1))
  {
$reg = $row["GroupReg"];
  }

if(md5($_POST["pass"])==$pwdmd5)
{
	$_SESSION["userid"] = $_POST["username"];
	$_SESSION["type"]="admin";
	header("Location: applicant1.php?view=applicantdetails&slid=$reg");
}
else
{
$log =  "Login failed.. Please try again..";
}
}
?>
