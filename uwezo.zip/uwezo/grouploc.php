<?php
session_start();
include("head.php");
if(isset($_SESSION["userid"]))
{
		if($_SESSION["type"]=="admin")
	{
?>							    <div align="center" id="menu"class="style12"><span class="style13"><a href="groupmembloan.php" ><h3>Next(3/3):Group Membership and Loan Information</h3></a><a href="#"><h3>~~~~~~~~</h3>
								    </a></span>
								      <p class="style13"><a href="groupreg.php"><h3>First(3/3): Group Information</h3></a><a href="#"><h3>~~~~~~~~</h3></a></p>
                                      								      <p class="style13"><a href="../contactview.php?view=0&slid=0"><h3> Check Enquiry Messages</h3></a></p>
                                      
</div>

<?php
//attempt connection to MySQL Database
$mysqli = new mysqli("localhost","root","","uwezo");
if ($mysqli === false) {
die("ERROR: Could not connect to database. " . mysqli_connect_error());
}
$submitted = false;
//if form submitted
//process form input
if(isset($_POST['submit'])) {
//open message block
$submitted = true;
echo '<div id="message">';

//retrieve and check input values
$inputError = false;
if (empty($_POST['grp_reg'])) {
echo 'ERROR: Please Enter a Valid Group Registration Number';
$inputError = true;

} else {
$reg = $mysqli->escape_string($_POST['grp_reg']);
}

if ($inputError != true && empty($_POST['grp_constituency'])) {
echo 'ERROR: Please Enter a Valid Constituency within which the Group is Located';
$inputError = true;
} else {
$const = $mysqli->escape_string($_POST['grp_constituency']);
}

if ($inputError != true && empty($_POST['grp_county'])) {
echo 'ERROR: Please Enter a valid County within which the Group is Located';
$inputError = true;
} else {
$county = $mysqli->escape_string($_POST['grp_county']);
}

if ($inputError != true && empty($_POST['grp_ward'])) {
echo 'ERROR: Please Enter a valid Ward within which the Group is Located';
$inputError = true;
} else {
$ward = $mysqli->escape_string($_POST['grp_ward']);
}

if ($inputError != true && empty($_POST['grp_location'])) {
echo 'ERROR: Please Enter a valid location within which the Group is Located';
$inputError = true;
} else {
$location = $mysqli->escape_string($_POST['grp_location']);
}

if ($inputError != true && empty($_POST['grp_sublocation'])) {
echo 'ERROR: Please Enter a valid Sub-Location within which the group is located';
$inputError = true;
} else {
$sublocation = $mysqli->escape_string($_POST['grp_sublocation']);
}
if ($inputError != true && empty($_POST['grp_chiefasstname'])) {
echo 'ERROR: Please Enter a valid Name of the Chief/Assistant Chief ';
$inputError = true;
} else {
$chiefasstname = $mysqli->escape_string($_POST['grp_chiefasstname']);
}
if ($inputError != true && empty($_POST['grp_chiefasstmobile'])) {
echo 'ERROR: Please Enter a valid Mobile Number of the Chief/Assistant Chief ';
$inputError = true;
} else {
$chiefasstmobile = $mysqli->escape_string($_POST['grp_chiefasstmobile']);
}
if ($inputError != true && empty($_POST['grp_bizarea'])) {
echo 'ERROR: Please Enter a valid Area where the Business of the Group is located';
$inputError = true;
} else {
$bizarea = $mysqli->escape_string($_POST['grp_bizarea']);
}

if ($inputError != true && empty($_POST['grp_areaname'])) {
echo 'ERROR: Please Enter a valid Name of the Area where the Business of the Group is located';
$inputError = true;
} else {
$areaname = $mysqli->escape_string($_POST['grp_areaname']);
}

if ($inputError != true && empty($_POST['grp_nearestLandmarkType'])) {
echo 'ERROR: Please Enter a valid Landmark Type nearest to where the Business of the Group is located';
$inputError = true;
} else {
$lmtype = $mysqli->escape_string($_POST['grp_nearestLandmarkType']);
}

if ($inputError != true && empty($_POST['grp_nearestLandmarkName'])) {
echo 'ERROR: Please Enter a valid Name for the Landmark where the Business of the Group is located';
$inputError = true;
} else {
$lmname = $mysqli->escape_string($_POST['grp_nearestLandmarkName']);
}

if ($inputError != true && empty($_POST['grp_streetplotNo'])) {
echo 'ERROR: Please Enter a valid Street/Plot Number of the business';
$inputError = true;
} else {
$streetplotno = $mysqli->escape_string($_POST['grp_streetplotNo']);
}
$optionB = $mysqli->escape_string($_POST['grp_biztype']);
if ($inputError != true && (empty($_POST['grp_biztype'])||$optionB =='Choose')) {
echo 'ERROR: Please Enter a valid type of Business the Group is involved in.';
$inputError = true;
} else {
$address = $mysqli->escape_string($_POST['grp_biztype']);
}

$optionA = $mysqli->escape_string($_POST['grp_jointbiz']);
if ($inputError != true && (empty($_POST['grp_jointbiz']) ||$optionA =='Choose')) {
echo 'ERROR: Please Enter a valid answer on whether the Business is a Joint Business';
$inputError = true;
} else {
$jointbiz = $mysqli->escape_string($_POST['grp_jointbiz']);
}
//add values to database using INSERT query
if ($inputError != true) {
$sql = "INSERT INTO tblgroupbizloc(GroupReg,GroupConstituency, GroupCounty, GroupWard, GroupLocation, GroupSubLocation, GroupChiefAsstName, GroupChiefAsstMobile,BizArea,BizAreaName,BizNearstLandmarkType,BizNearstLandmarkName,BizStreetPlotNo,BizType,JointBiz) VALUES ('$const','$county','$ward','$location', '$sublocation', '$chiefasstname','$chiefasstmobile','$bizarea','$areaname','$lmtype','$lmname','$streetplotno','$biztype,'$jointbiz')";
		if ($mysqli->query($sql) === true) {
		echo 'New record Added with ID: ' .$reg;
		} else {
		echo "ERROR: Could not execute query: $sql. " . $mysqli->error;
		}
	}
	//close message block
	echo '</div>';
	}
	if (($submitted == true && $inputError == false) || $submitted == false) {
	?>
	</div>
		
	<h3> Group and Business Location - Submissions</h3>
        <h5>&nbsp;</h5>
	<?php
	}
	//get records
	//format as HTML table
	$sql = "SELECT GroupReg,GroupConstituency, GroupCounty, GroupWard, GroupLocation, GroupSubLocation, GroupChiefAsstName, GroupChiefAsstMobile,BizArea,BizAreaName,BizNearstLandmarkType,BizNearstLandmarkName,BizStreetPlotNo,BizType,JointBiz FROM tblgroupbizloc";
	if ($result = $mysqli->query($sql)) {
	if ($result->num_rows > 0) {
		echo "<table border='1'>\n";
	echo "<tr class=\"heading\">\n";
	echo "<td>Reg</td>\n";
	echo "<td>Constituency</td>\n";
	echo "<td>County</td>\n";
	echo "<td>Ward</td>\n";
	echo "<td>Location</td>\n";
	echo "<td>Sub-Location</td>\n";
	echo "<td>Chief/Asst._Name</td>\n";
	echo "<td>Chief/Asst._Cell</td>\n";
	echo "<td>BizArea</td>\n";
	echo "<td>BizArea_Name</td>\n";
	echo "<td>Nearest_LandmarkType</td>\n";
	echo "<td>Nearest_LandmarkName</td>\n";
	echo "<td>BizStreet/Plot_No</td>\n";
	echo "<td>BizType</td>\n";
	echo "<td>JointBiz?</td>\n";
	echo "</tr>\n";
	while ($row=$result->fetch_object()) {
	
	echo "<tr>\n";
	echo "<td>" .  $row->GroupReg . "</td>\n";
	echo "<td>" .  $row->GroupConstituency . "</td>\n";
	echo "<td>" .  $row->GroupCounty . "</td>\n";
	echo "<td>" .  $row->GroupWard . "</td>\n";
	echo "<td>" .  $row->GroupLocation . "</td>\n";
	echo "<td>" .  $row->GroupSubLocation . "</td>\n";
	echo "<td>" .  $row->GroupChiefAsstName. "</td>\n";
	echo "<td>" .  $row->GroupChiefAsstMobile . "</td>\n";
	echo "<td>" .  $row->BizArea . "</td>\n";
	echo "<td>" .  $row->BizAreaName . "</td>\n";
	echo "<td>" .  $row->BizNearstLandmarkType . "</td>\n";
	echo "<td>" .  $row->BizNearstLandmarkName . "</td>\n";
	echo "<td>" .  $row->BizStreetPlotNo . "</td>\n";
	echo "<td>" .  $row->BizType . "</td>\n";
	echo "<td>" .  $row->JointBiz . "</td>\n";
	echo "</tr>\n";
	}
	echo "</table>";
	$result->close();
	} else {
	echo "No Group Locations in database.";
	}
	}else {
	echo "ERROR: Could not execute query: $sql. " . $mysqli->error;
	}
	//close connection
	$mysqli->close();
	?>
</body>
</html>
<?php 
}
}
else
{
		header("Location: index.php");
}


?>