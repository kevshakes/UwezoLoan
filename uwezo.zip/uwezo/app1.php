<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title>Uwezo Fund - Online Loan Application</title>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
		<!-- Begin JavaScript -->

		<script type="text/javascript" src="lib/jquery-1.3.2.min.js"></script>
		<script type="text/javascript" src="lib/jquery.tools.js"></script>
    	<script type="text/javascript" src="lib/jquery.custom.js"></script>
		<script type="text/javascript" src="lib/validate.js"></script>
<link href="images/icon.png"rel="shortcut icon" type="image" />
        <link href="styles.css" rel="stylesheet" type="text/css" media="screen" />
        <style type="text/css">
<!--
.style1 {color: #CCCCCC}
.style6 {color: #000000}
.style10 {font-weight: bold}
.style11 {font-size: large}
.style12 {color: #F0F0F0}
#Layer8 {	position:absolute;
	width:300px;
	height:115px;
	z-index:3;
	left: 16px;
	top: 12px;
}
.style13 {font-size: 14px}
-->
        </style>
</head>
<?php
session_start(); 
include("conection.php");
include("validation.php");
include 'session.inc';
if (!isset ($_SESSION['admin']))
{
//header ("location:index.php");
}

?>
<?php
if(isset($_POST["button"]))
{
$sql="INSERT INTO tblgroupinfo(GroupName, GroupReg, GroupDateOfReg, GroupTown, GroupBankAcc, GroupBank, GroupBankBra,GroupPostCode,GroupAddress) VALUES
('$_POST[grp_name]','$_POST[grp_reg]','$_POST[grp_date]','$_POST[grp_town]','$_POST[grp_bankac]','$_POST[grp_bank]','$_POST[grp_bankbra]','$_POST[grp_postcode]','$_POST[grp_address]')";

if (!mysql_query($sql,$con))
  {
  
  die('Error: ' . mysql_error());
  }
  else
  {
	  echo "Group Information Submitted Successfully...";
  }
}

$result = mysql_query("SELECT * FROM tblgroupinfo");
$result1 = mysql_query("SELECT * FROM tblgroupbizloc");

if(isset($_POST["button2"]))
{
mysql_query("UPDATE tblgroupinfo SET GroupName='$_POST[grp_name]', 		 	GroupDateOfReg='$_POST[grp_date]', 	GroupTown='$_POST[grp_town]', GroupBankAcc='$_POST[grp_bankac]', 		GroupBank='$_POST[grp_bank]', 	GroupBankBra='$_POST[grp_bankbra]', 	GroupPostCode='$_POST[grp_postcode],GroupAddress='$_POST[grp_address]' WHERE GroupReg='$_POST[grp_reg]'");
echo "Group Information updated successfully...";
}

if(isset($_SESSION["userid"]))
{
?>

    <body>
        <div id="content_bg">
        	<div id="wraps">
        		<div id="top_wrap">
        			<div id="logo">
        				<h1><span class="style10"><a href="index.html">Welcome to Uwezo Fund Loan Application Portal </a></span></h1>
                    	<div id="Layer8"><img src="images/contacts.png" width="350" height="144" style="border:inset;border-color:#0099FF"/></div>
                    	<strong><a href="#"><small>Ahadi Yetu - Kazi Kwako </small></a></strong>
                    	<h1>&nbsp; </h1>
       			  </div>
					<div class="header"><div>
							<ul><li class="button_box style11"></li>
							  <li class="button_box style11">
							    <div align="center" id="menu"class="style12"><span class="style13"><a href="app1.php" >Update Group Info </a><a href="contact.php"> Report Issue </a><a href="<?php session_destroy();  ?>" class="active"> Log Out </a></span></div>
						      </li>
							</ul>
						</div>
				  </div>
        		</div>
				<div id="content">
					<div id="content_top"></div>
					<div id="content_bg">
						<div class="content_left">
							<div class="blog_news">
								<h6>Uwezo Fund Loan Application - Youth/Women Group Information </h6>
							    <div class="news_bar">
							    <div class="clear">
							      <p>&nbsp;</p>
							      <p class="style1 style6"> <span id="feedback" class="style6"><strong>Group Name</strong></span> </p>
							      <form name ="form1"id="formID" method="post" action="groupreg.php">

                                    <fieldset>
                                    <p>

																	
                                      <input id="grp_name" type="text" name="grp_name" class="validate[required,custom[onlyLetterSp]] text-input" alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Registration No/Serial No:</strong></span><br />
                                      <input id="grp_reg" type="text" name="grp_reg" class="validate[required]text-input"  alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Date of Registration:</strong></span><br />
    <script src="datetimepicker_css.js"></script>

    <input type="Text" name="grp_date" id="textdob" class="validate[required,[date]]text-input"  maxlength="25" size="25"/>
        <img src="images/cal.gif" onclick="javascript:NewCssCal ('textdob')"  style="cursor:pointer"/>
                                    <p><span class="style6"><strong>Town:</strong></span></p>
                                    <p>
									   <input id="grp_reg" type="text" name="grp_town" value="" class="validate[required] text-input" alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Bank Account:</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_bankac" class="validate[required,custom[onlyNumberSp]] text-input" alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Bank Name:</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_bank" class="validate[required,custom[onlyLetterSp]] text-input" alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Bank Branch</strong></span></p></p>
                                    <p>
                                      <input id="grp_reg" class="validate[required,custom[onlyLetterSp]] text-input" type="text" name="grp_bankbra"alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Postal Code:</strong></span></p>
                                    <p>
                                      <input id="grp_reg" type="text" name="grp_postcode"  class="validate[required,custom[onlyNumberSp]] text-input"alt=""/>
                                    </p>
                                    <p><span class="style6"><strong>Postal Address</strong></span><br />
                                        <textarea id="con_address" name="grp_address" class="validate[required] text-input" cols="0" rows="0"></textarea>
                                      <br />
                                        <input name="submit" type="submit" id="contact-submit" value="Submit Group Information"/>
                                    </p>
                                    </p>
                                    </fieldset>
						          </form>

							    </div>
							  </div>
						  </div>
							<div class="blog_news">
							  <div class="clear"></div>
							</div>			
						</div>
						<div class="clear"></div>
					</div>
					<div id="content_bot"></div>
				</div>
				<div id="footer">
					<div id="footer_column">
						<div id="footer_con_bg">
							<div id="footer_con_top">
								<div id="footer_con_bot">
								
              
							<div class="clear"></div>
							<div class="button_box">
								<blockquote>
								  <blockquote>
                                    <p><a href="http://www.facebook.com"><img src="images/facebook.png" alt="" title=""/></a> 
									<a href="http://www.twitter.com"><img src="images/twitter.png" alt="" title=""/></a> 
									<a href="http://www.yahoo.com"><img src="images/yahoo.png" alt="" title=""/></a> 
									<a href="http://www.rss.com"><img src="images/rss.png" alt="" title=""/></a> 
									<a href="http://www.youtube.com"><img src="images/youtube.png" alt="" title=""/></a></p>
							            </p>
							      </blockquote>
							  </blockquote>
                        </div>
                        <div style="clear: both"></div>								
								</div>
							</div>
						</div>
					</div>
					<div id="footer_bot">
						<p>Copyright  2014. </p>
                        <!-- Please DO NOT remove the following notice --><p>Design by <a href="http://facebook.com/ktuei" title="COMP402 Computer Systems Project">Kevin Tuei, EBS1/02955/10</a></p><!-- end of copyright notice-->
					</div>
				</div>	
        	</div>
        </div>
    </body>
</html>
<?php
}
else {
echo "<h3'> <a href='index.php'>Please login to access the portal</a> </h3>";
}
?>